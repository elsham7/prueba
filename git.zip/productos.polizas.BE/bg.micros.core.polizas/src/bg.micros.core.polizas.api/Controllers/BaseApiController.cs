﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace bg.micros.core.polizas.api.Controllers
{    
    [ApiController]
    public abstract class BaseApiController : ControllerBase
    {
    }
}
