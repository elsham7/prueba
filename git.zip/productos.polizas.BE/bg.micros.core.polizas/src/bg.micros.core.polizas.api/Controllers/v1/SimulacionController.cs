﻿using bg.micros.core.polizas.application.interfaces.services;
using bg.micros.core.polizas.application.models.dtos;
using bg.micros.core.polizas.domain.entities.simulacion;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace bg.micros.core.polizas.api.Controllers.v1
{
    [ApiExplorerSettings(GroupName = "v1")]
    public class SimulacionController : BaseApiController
    {
        private readonly ISimulacionRepository _simulacionRepository;

        public SimulacionController(ISimulacionRepository _simulacionRepository)
        {
            this._simulacionRepository = _simulacionRepository;
        }

        /// <summary>
        /// Calculo de poliza cache - core
        /// </summary>          
        [HttpGet]
        [Route("productos/v1/polizas/simulacion")]
        [Consumes("application/json")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(MsDtoResponse<ConsultaSimulacionDTO>), 200)]
        [ProducesResponseType(typeof(MsDtoResponseError), 400)]
        [ProducesResponseType(typeof(MsDtoResponseError), 500)]
        public async Task<ActionResult<MsDtoResponse<ConsultaSimulacionDTO>>> GeneraSimulacion([FromHeader][Required] decimal monto, [FromHeader][Required] int plazo, [FromHeader][Required] string tipoPlazo, [FromHeader] bool generarRecomendaciones = false, [FromHeader] decimal montoAcumulado = 0M)
        {
            ConsultaSimulacionDTO _response = await _simulacionRepository.GeneraSimulacion(new ConsultaSimulacionRequest { Monto = monto, Plazo = plazo, TipoPlazo = tipoPlazo, GenerarRecomendaciones= generarRecomendaciones, MontoAcumulado= montoAcumulado });
            return Ok(new MsDtoResponse<ConsultaSimulacionDTO>(_response, HttpContext.TraceIdentifier));
        }

        /// <summary>
        /// Calculo de poliza con datos de core
        /// </summary>          
        [HttpGet]
        [Route("productos/v1/polizas/simulacion-core")]
        [Consumes("application/json")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(MsDtoResponse<ConsultaSimulacionDTO>), 200)]
        [ProducesResponseType(typeof(MsDtoResponseError), 400)]
        [ProducesResponseType(typeof(MsDtoResponseError), 500)]
        public async Task<ActionResult<MsDtoResponse<ConsultaSimulacionDTO>>> GeneraSimulacionCore([FromHeader][Required] decimal monto, [FromHeader][Required] int plazo, [FromHeader][Required] string tipoPlazo, [FromHeader] bool consumirCore= false, [FromHeader] bool generarRecomendaciones = false, [FromHeader] decimal montoAcumulado = 0M)
        {
            ConsultaSimulacionDTO _response = await _simulacionRepository.GeneraSimulacion(new ConsultaSimulacionRequest { Monto = monto, Plazo = plazo, TipoPlazo = tipoPlazo, GenerarRecomendaciones = generarRecomendaciones, MontoAcumulado= montoAcumulado }, consumirCore);
            return Ok(new MsDtoResponse<ConsultaSimulacionDTO>(_response, HttpContext.TraceIdentifier));
        }
    }
}
