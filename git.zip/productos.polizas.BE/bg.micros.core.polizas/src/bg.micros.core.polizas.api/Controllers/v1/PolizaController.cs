﻿using bg.micros.core.polizas.application.interfaces.services;
using bg.micros.core.polizas.application.models.dtos;
using bg.micros.core.polizas.domain.entities.datospolizas;
using bg.micros.core.polizas.domain.entities.polizas;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace bg.micros.core.polizas.api.Controllers.v1
{
    [ApiExplorerSettings(GroupName = "v1")]
    [Route("productos/v1/polizas")]
    public class PolizaController : BaseApiController
    {
        public readonly IDetallePolizaRepository _detallePolizaRepository;

        public PolizaController(IDetallePolizaRepository _detallePolizaRepository)
        {
            this._detallePolizaRepository = _detallePolizaRepository;
        }
        /// <summary>
        /// Obtener detalle de poliza
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("detalle")]
        [Consumes("application/json")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(MsDtoResponse<ResponseDetallePoliza>), 200)]
        [ProducesResponseType(typeof(MsDtoResponseError), 400)]
        [ProducesResponseType(typeof(MsDtoResponseError), 500)]
        public async Task<ActionResult<MsDtoResponse<ResponseDetallePoliza>>> ObtenerDetallePoliza([FromBody][Required] RequestDetallePoliza request)
        {
            ResponseDetallePoliza _response = await _detallePolizaRepository.ObtenerDetallePoliza(request);
            return Ok(new MsDtoResponse<ResponseDetallePoliza>(_response, HttpContext?.TraceIdentifier));
        }

        /// <summary>
        /// Obtiene la información de Pólizas
        /// </summary>
        /// <param name="agencia" example="192">ID de la agencia EJEMPLO: 192 </param>
        /// <param name="documento" example="1141">Número de documento EJEMPLO: 1141</param>
        /// <param name="tipo" example="V">Tipo de documento EJEMPLO: V</param>
        [HttpGet]
        [Route("informacion")]
        [Consumes("application/json")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(MsDtoResponse<DatosPolizas>), 200)]
        [ProducesResponseType(typeof(MsDtoResponseError), 400)]
        [ProducesResponseType(typeof(MsDtoResponseError), 500)]
        public async Task<ActionResult<MsDtoResponse<DatosPolizas>>> ObtenerDatosPoliza([FromHeader] string? agencia, 
                                                                                        [FromHeader] string? documento,
                                                                                        [FromHeader] string? tipo)
        {
            DatosPolizasRequest request = new DatosPolizasRequest() 
            {
                agencia = agencia,
                documento = documento,
                tipo = tipo
            };

            DatosPolizas _response = await _detallePolizaRepository.ObtenerDatosPoliza(request);
            return Ok(new MsDtoResponse<DatosPolizas>(_response, HttpContext?.TraceIdentifier));
        }

    }
}
