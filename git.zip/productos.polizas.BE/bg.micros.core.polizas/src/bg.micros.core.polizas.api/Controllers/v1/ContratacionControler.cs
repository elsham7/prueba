﻿using bg.micros.core.polizas.application.interfaces.services;
using bg.micros.core.polizas.application.models.dtos;
using bg.micros.core.polizas.domain.entities.webServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace bg.micros.core.polizas.api.Controllers.v1
{
    [ApiExplorerSettings(GroupName = "v1")]
    public class Contratacion: BaseApiController
    {
        private readonly IContratacionPolizaRepository _contratacionPolizaRepository;

        public Contratacion(IContratacionPolizaRepository _contratacionPolizaRepository)
        {
            this._contratacionPolizaRepository = _contratacionPolizaRepository;
        }

        /// <summary>
        /// Genera registros de contratacion de poliza
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("contratacion-producto")]
        [Consumes("application/json")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(MsDtoResponse<PolizaContratacionDTO>), 200)]
        [ProducesResponseType(typeof(MsDtoResponseError), 400)]
        [ProducesResponseType(typeof(MsDtoResponseError), 500)]
        public async Task<ActionResult<MsDtoResponse<PolizaContratacionDTO>>> ContratarPoliza([FromBody][Required] PolizaContratacionDTO request)
        {
            PolizaContratacionDTO _response = await _contratacionPolizaRepository.ContratarPoliza(request);
            return Ok(new MsDtoResponse<PolizaContratacionDTO>(_response, HttpContext?.TraceIdentifier));
        }
        /// <summary>
        /// Consulta de tasa de interes y fechas a CORE
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("consulta-tasa-interes")]
        [Consumes("application/json")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(MsDtoResponse<ConsultaTasaInteresResponseDTO>), 200)]
        [ProducesResponseType(typeof(MsDtoResponseError), 400)]
        [ProducesResponseType(typeof(MsDtoResponseError), 500)]
        public async Task<ActionResult<MsDtoResponse<ConsultaTasaInteresResponseDTO>>> ConsultaTasaInteres([FromBody][Required] ConsultaTasaInteresDTO request)
        {
            ConsultaTasaInteresResponseDTO _response = await _contratacionPolizaRepository.ConsultaTasaInteres(request);
            return Ok(new MsDtoResponse<ConsultaTasaInteresResponseDTO>(_response, HttpContext?.TraceIdentifier));
        }
    }
}
