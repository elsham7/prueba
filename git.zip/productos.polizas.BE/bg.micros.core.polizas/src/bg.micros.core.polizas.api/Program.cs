using bg.micros.core.polizas.application.ioc;
using bg.micros.core.polizas.api.Extentions;
using bg.micros.core.polizas.infrastructure.extentions;
using bg.micros.core.polizas.infrastructure.ioc;
using Microsoft.OpenApi.Models;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using bg.micros.core.polizas.infrastructure.security;
using Microsoft.AspNetCore.Authentication.JwtBearer;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
//Parametros Entorno
builder = builder.ConfigureEnvironmentVariable();

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{   
    var version = builder.Configuration["OpenApi:info:version"];
    var title = builder.Configuration["OpenApi:info:title"];
    var description = builder.Configuration["OpenApi:info:description"];
    var termsOfService = new Uri(builder.Configuration["OpenApi:info:termsOfService"]);
    var contact = new OpenApiContact
    {
        Name = builder.Configuration["OpenApi:info:contact:name"],
        Url = new Uri(builder.Configuration["OpenApi:info:contact:url"]),
        Email = builder.Configuration["OpenApi:info:contact:email"]
    };
    var license = new OpenApiLicense
    {
        Name = builder.Configuration["OpenApi:info:License:name"],
        Url = new Uri(builder.Configuration["OpenApi:info:License:url"])
    };
    options.SwaggerDoc("v1", new OpenApiInfo
    {
        Version = "v1",
        Title = title,
        Description = description,
        TermsOfService = termsOfService,
        Contact = contact,
        License = license
    });
    options.SwaggerDoc(builder.Configuration["OpenApi:info:version"], new OpenApiInfo
    {
        Version = builder.Configuration["OpenApi:info:version"],
        Title = title,
        Description = description,
        TermsOfService = termsOfService,
        Contact = contact,
        License = license
    });
    var jwtSecurityScheme = new OpenApiSecurityScheme
    {
        Scheme = "bearer",
        BearerFormat = "JWT",
        Name = "JWT Authentication",
        In = ParameterLocation.Header,
        Type = SecuritySchemeType.Http,
        Description = "JWT Authorization header using the Bearer scheme. \r\n\r\n Put **_ONLY_** your JWT Bearer **_token_** on textbox below! \r\n\r\n\r\n Example: \"Value: **12345abcdef**\"",

        Reference = new OpenApiReference
        {
            Id = JwtBearerDefaults.AuthenticationScheme,
            Type = ReferenceType.SecurityScheme
        }
    };
    options.AddSecurityDefinition(jwtSecurityScheme.Reference.Id, jwtSecurityScheme);
    options.OperationFilter<RequiredHeaderParameter>();
    List<string> xmlFiles = Directory.GetFiles(AppContext.BaseDirectory, "*.xml", SearchOption.TopDirectoryOnly).ToList();
    xmlFiles.ForEach(xmlFile => options.IncludeXmlComments(xmlFile));

});


//Dependencias propias de Servicio
builder.Services.RegisterDependencies();
builder.Services.AddInfrastructure(builder.Configuration);
builder.Services.AddApplication();



builder.Services.AddHealthChecks();


//Config Authentication Tokes
builder.Services.SetupAuthenticationServices(builder);
//CacheInMemory
builder.Services.AddMemoryCache();
var app = builder.Build();




// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint($"/swagger/v1/swagger.json", $"v1");
        c.SwaggerEndpoint($"/swagger/v2/swagger.json", $"v2");
    });
}


app.ConfigureMetricServer();
app.ConfigureExceptionHandler();

app.UseAuthentication();
app.UseAuthorization();



app.MapHealthChecks("/health/readiness", new HealthCheckOptions
{
    AllowCachingResponses = false,
    ResultStatusCodes =
    {
        [HealthStatus.Healthy] = StatusCodes.Status200OK,
        [HealthStatus.Degraded] = StatusCodes.Status200OK,
        [HealthStatus.Unhealthy] = StatusCodes.Status503ServiceUnavailable
    },
});

app.MapHealthChecks("/health/liveness", new HealthCheckOptions
{
    AllowCachingResponses = false,
    ResultStatusCodes =
    {
        [HealthStatus.Healthy] = StatusCodes.Status200OK,
        [HealthStatus.Degraded] = StatusCodes.Status200OK,
        [HealthStatus.Unhealthy] = StatusCodes.Status503ServiceUnavailable
    },
    Predicate = _ => false
});



app.MapControllers();




app.Run();
