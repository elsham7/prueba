﻿using bg.micros.core.polizas.domain.entities.webServices;
using System.IO;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace bg.micros.core.polizas.infrastructure.utils
{
    public class XmlHelper
    {
        public static Diffgram DeserializeXmlFromXElement(XElement xElement)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(Diffgram));

            using (StringReader reader = new StringReader(xElement.ToString()))
            {
                return (Diffgram)serializer.Deserialize(reader);
            }
        }
    }

}
