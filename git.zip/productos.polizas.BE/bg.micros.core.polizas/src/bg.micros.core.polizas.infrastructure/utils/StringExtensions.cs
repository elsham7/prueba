﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace bg.micros.core.polizas.infrastructure.utils
{
    public static class StringExtensions
    {
        public static string RemoveSpecialCharacters(this string input)
        {
            if (string.IsNullOrEmpty(input))
                return input;
            return Regex.Replace(input, @"[\u0000-\u001F\u007F-\u009F]", string.Empty);
        }
    }
}
