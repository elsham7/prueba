﻿using AutoMapper;
using bg.micros.core.polizas.domain.entities.polizas;
using refPolizas = bg.micros.core.polizas.domain.entities.polizas.dataservices;
using refDatosPolizaDto = bg.micros.core.polizas.domain.entities.datospolizas.dataservices;
using bg.micros.core.polizas.domain.entities.datospolizas;
using bg.micros.core.polizas.domain.entities.webServices;
using System.Data;
using System.Text;
using WS_ExpedientePoliza;
using System.Xml.Linq;
using WS_ContratacionProductosOnline;
using bg.micros.core.polizas.infrastructure.utils;

namespace bg.micros.core.polizas.infrastructure.mappings
{
    public class MappingProfile : Profile
    {

        public MappingProfile()
        {            
            #region Detalle-Poliza
            CreateMap<refPolizas.Data, ResponseDetallePolizaItem>()
                .ForMember(dest => dest.marcaRenovacion, opt => opt.MapFrom(src => src.marca_renovacion))
                .ForMember(dest => dest.descripcionRenovacion, opt => opt.MapFrom(src => src.descripcion_renovacion))
                .ForMember(dest => dest.codigoPeriocidad, opt => opt.MapFrom(src => src.codigo_periocidad))
                .ForMember(dest => dest.descripcionPeriocidad, opt => opt.MapFrom(src => src.descripcion_periocidad))
                .ForMember(dest => dest.beneficiario, opt => opt.MapFrom(src => src.beneficiario))
                .ForMember(dest => dest.origenPoliza, opt => opt.MapFrom(src => src.origen_poliza))
                .ForMember(dest => dest.agencia, opt => opt.MapFrom(src => src.agencia))
                .ForMember(dest => dest.documento, opt => opt.MapFrom(src => src.documento))
                .ForMember(dest => dest.titular, opt => opt.MapFrom(src => src.titular))
                .ForMember(dest => dest.fechaEmision, opt => opt.MapFrom(src => src.fecha_emision))
                .ForMember(dest => dest.plazo, opt => opt.MapFrom(src => src.plazo))
                .ForMember(dest => dest.fechaVencimiento, opt => opt.MapFrom(src => src.fecha_vencimiento))
                .ForMember(dest => dest.capital, opt => opt.MapFrom(src => src.capital))
                .ForMember(dest => dest.tasaInteres, opt => opt.MapFrom(src => src.tasa_interes))
                .ForMember(dest => dest.interesesCobrados, opt => opt.MapFrom(src => src.interes_cobrado))
                .ForMember(dest => dest.interesesPorCobrar, opt => opt.MapFrom(src => src.interes_x_cobrar))
                .ForMember(dest => dest.impuestosCobrados, opt => opt.MapFrom(src => src.impuesto_cobrado))
                .ForMember(dest => dest.impuestosPorCobrar, opt => opt.MapFrom(src => src.impuesto_x_cobrar))
                .ForMember(dest => dest.fechaProximoCobroIntereses, opt => opt.MapFrom(src => src.fecha_proximo_cobro_intereses))
                .ForMember(dest => dest.monto, opt => opt.MapFrom(src => src.monto))
                .ForMember(dest => dest.tipoInversion, opt => opt.MapFrom(src => src.tipo_inversion))
                .ForMember(dest => dest.identificacion, opt => opt.MapFrom(src => src.identificacion))
                .ForMember(dest => dest.codigoDactilar, opt => opt.MapFrom(src => src.a))
                .ForMember(dest => dest.status, opt => opt.MapFrom(src => src.pzk_status))
                .ForMember(dest => dest.codigoRetorno, opt => opt.MapFrom(src => src.codigoretorno));
            #endregion

            #region Datos-Polizas

            CreateMap<refDatosPolizaDto.FormaCancelar, FormaCan>()
            .ForMember(dest => dest.formaDeCancelar, opt => opt.MapFrom(src => src.forma_de_cancelar.RemoveSpecialCharacters()))
            .ForMember(dest => dest.numeroDeCuenta, opt => opt.MapFrom(src => src.numero_de_cuenta))
            .ForMember(dest => dest.valor, opt => opt.MapFrom(src => src.valor));

            CreateMap<refDatosPolizaDto.FormaPagar, FormaPago>()
            .ForMember(dest => dest.formaDePago, opt => opt.MapFrom(src => src.forma_de_pago.RemoveSpecialCharacters()))
            .ForMember(dest => dest.numeroDeCuenta, opt => opt.MapFrom(src => src.numero_de_cuenta))
            .ForMember(dest => dest.valor, opt => opt.MapFrom(src => src.valor));

            CreateMap <refDatosPolizaDto.DatosGeneralesPolizas, DatosGeneralesPolizas>()
            .ForMember(dest => dest.identificacion, opt => opt.MapFrom(src => src.identificacion))
            .ForMember(dest => dest.cliente, opt => opt.MapFrom(src => src.cliente))
            .ForMember(dest => dest.numeroPoliza, opt => opt.MapFrom(src => src.numero_poliza))
            .ForMember(dest => dest.tipoInversion, opt => opt.MapFrom(src => src.tipo_inversion))
            .ForMember(dest => dest.capital, opt => opt.MapFrom(src => src.capital))
            .ForMember(dest => dest.tasa, opt => opt.MapFrom(src => src.tasa))
            .ForMember(dest => dest.plazoDias, opt => opt.MapFrom(src => src.plazo_dias))
            .ForMember(dest => dest.valorInteresGanado, opt => opt.MapFrom(src => src.valor_interes_ganado))
            .ForMember(dest => dest.impuestoPorc_2, opt => opt.MapFrom(src => src.impuesto_porc_2))
            .ForMember(dest => dest.valImpuesto, opt => opt.MapFrom(src => src.val_impuesto))
            .ForMember(dest => dest.netoRecibir, opt => opt.MapFrom(src => src.neto_recibir))
            .ForMember(dest => dest.canal, opt => opt.MapFrom(src => src.canal))
            .ForMember(dest => dest.fechaEmision, opt => opt.MapFrom(src => src.fecha_emision))
            .ForMember(dest => dest.fechaVcto, opt => opt.MapFrom(src => src.fecha_vcto))
            .ForMember(dest => dest.fechaRevision, opt => opt.MapFrom(src => src.fecha_revision))
            .ForMember(dest => dest.agencia, opt => opt.MapFrom(src => src.agencia))
            .ForMember(dest => dest.periodosPagoint, opt => opt.MapFrom(src => src.periodos_pagoint))
            .ForMember(dest => dest.revisor, opt => opt.MapFrom(src => src.revisor))
            .ForMember(dest => dest.cuentaPagoint, opt => opt.MapFrom(src => src.cuenta_pagoint))
            .ForMember(dest => dest.clienteAnterior, opt => opt.MapFrom(src => src.cliente_anterior))
            .ForMember(dest => dest.observacion, opt => opt.MapFrom(src => src.observacion))
            .ForMember(dest => dest.ruteoApro1, opt => opt.MapFrom(src => src.ruteo_apro1))
            .ForMember(dest => dest.ruteoApro2, opt => opt.MapFrom(src => src.ruteo_apro2))
            .ForMember(dest => dest.ruteoApro3, opt => opt.MapFrom(src => src.ruteo_apro3))
            .ForMember(dest => dest.ruteoApro4, opt => opt.MapFrom(src => src.ruteo_apro4))
            .ForMember(dest => dest.opidRevision, opt => opt.MapFrom(src => src.opid_revision))
            .ForMember(dest => dest.opidImpresion, opt => opt.MapFrom(src => src.opid_impresion))
            .ForMember(dest => dest.terminalImpresion, opt => opt.MapFrom(src => src.terminal_impresion))
            .ForMember(dest => dest.fechaImpresion, opt => opt.MapFrom(src => src.fecha_impresion))
            .ForMember(dest => dest.horaImpresion, opt => opt.MapFrom(src => src.hora_impresion))
            .ForMember(dest => dest.numeroImpresion, opt => opt.MapFrom(src => src.numero_impresion))
            .ForMember(dest => dest.nombreBeneficiario, opt => opt.MapFrom(src => src.nombre_beneficiario))
            .ForMember(dest => dest.renovacionautomatica, opt => opt.MapFrom(src => src.renovacionautomatica))
            .ForMember(dest => dest.formaPago, opt => opt.MapFrom(src => src.forma_pago))
            .ForMember(dest => dest.formaCan, opt => opt.MapFrom(src => src.forma_can));

            CreateMap<refDatosPolizaDto.DataDatosPolizas,DatosPolizas>()
                .ForMember(dest => dest.datosGeneralesPoliza, opt => opt.MapFrom(src => src.datos_generales_poliza));

            #endregion

            #region Mapeo de WS Neo
            CreateMap<PolizaContratacionDTO, CrearLogicaPolizasAppRequest>()
           .ConstructUsing(dto => new CrearLogicaPolizasAppRequest(
               dto.TipoIdentificacion ?? string.Empty,
               dto.NumIdentificacion ?? string.Empty,
               dto.IdProducto ?? string.Empty,
               dto.IdCanal ?? string.Empty,
               dto.Capital ?? string.Empty,
               dto.Plazo ?? string.Empty,
               dto.TasaInteres ?? string.Empty,
               dto.InteresRecibir ?? string.Empty,
               dto.MargenTasa ?? string.Empty,
               dto.TasaSolicitada ?? string.Empty,
               dto.MargenTasaSolicitada ?? string.Empty,
               dto.ImpuestoCobrado ?? string.Empty,
               dto.InteresNeto ?? string.Empty,
               dto.InteresCobrado ?? string.Empty,
               dto.MontoNetoRecibir ?? string.Empty,
               dto.PorcentajeImpuesto ?? string.Empty,
               dto.FechaEmision ?? string.Empty,
               dto.FechaVencimiento ?? string.Empty,
               dto.RenovacionAut ?? string.Empty,
               dto.NumDocumento ?? string.Empty,
               dto.OpidOficialCli ?? string.Empty,
               dto.OpidOficialIng ?? string.Empty,
               dto.PolizaAnterior ?? string.Empty,
               dto.Estado ?? string.Empty,
               dto.AutorizaMargen ?? string.Empty,
               dto.NumeroCuenta ?? string.Empty,
               dto.TipoCuenta ?? string.Empty,
               dto.TipoPoliza ?? string.Empty,
               dto.Periodicidad ?? string.Empty,
               dto.IdModulo ?? string.Empty,
               dto.idFormulario ?? string.Empty,
               dto.StrNumTrazabilidad ?? string.Empty,
               dto.Usuario ?? string.Empty,
               dto.StrIP ?? string.Empty,
               dto.Docum ?? string.Empty,
               dto.IdExpedienteGenerado ?? string.Empty,
               dto.CodigoRetorno ?? string.Empty,
               dto.MensajeRetorno ?? string.Empty,
               dto.Observaciones ?? string.Empty
           ));

            CreateMap<GeneralCampos, GeneralCamposDto>()
                .ForMember(dest => dest.LstCampos, opt => opt.MapFrom(src => src.lstCampos)) 
                .ForMember(dest => dest.CodigoError, opt => opt.MapFrom(src => src.codigoError))
                .ForMember(dest => dest.MensajeError, opt => opt.MapFrom(src => src.mensajeError))
                .ForMember(dest => dest.ResultadoConsultas, opt => opt.Ignore())
                .ForMember(dest => dest.Formulario, opt => opt.MapFrom(src => src.Formulario))
                .ForMember(dest => dest.ListadoCampos, opt => opt.MapFrom(src => src.listadoCampos))
                .AfterMap((src, dest) =>
                {
                    dest.ResultadoConsultas = TryConvertToDataSet(src.resultadoConsultas);
                });

            CreateMap<Campo, CampoDto>()
                .ForMember(dest => dest.TipoDato, opt => opt.MapFrom(src => src.TipoDato))
                .ForMember(dest => dest.ValorDato, opt => opt.MapFrom(src => src.ValorDato))
                .ForMember(dest => dest.TamanioDato, opt => opt.MapFrom(src => src.TamanioDato))
                .ForMember(dest => dest.NombreDato, opt => opt.MapFrom(src => src.NombreDato));

            CreateMap<ConsultaTasaInteresDTO, ConsultaTasaInteresRequest>()
           .ConstructUsing(dto => new ConsultaTasaInteresRequest(
               dto.TipoIdentificacion ?? string.Empty,
               dto.NumeroIdentificacion ?? string.Empty,
               dto.Monto ?? string.Empty,
               dto.Plazo ?? string.Empty,
               dto.Moneda ?? string.Empty,
               dto.FechaInversion ?? string.Empty,
               dto.CalculoTasa ?? string.Empty,
               dto.IdFormulario ?? string.Empty,
               dto.IdModulo ?? string.Empty,
               dto.StrUsuario ?? string.Empty
               
           ));

            CreateMap<ConsultaTasaInteresResponse, ConsultaTasaInteresResponseDTO>()
                .ForMember(dest => dest.CodigoRetorno, opt => opt.MapFrom(src => src.CodigoRetorno))
                .ForMember(dest => dest.MensajeRetorno, opt => opt.MapFrom(src => src.MensajeRetorno))
                .ForMember(dest => dest.Tasa, opt => opt.Ignore())
                .ForMember(dest => dest.FechaVencimiento, opt => opt.Ignore())
                .ForMember(dest => dest.AutorizaMargen, opt => opt.Ignore())
                .ForMember(dest => dest.FechaEmision, opt => opt.Ignore())
                .AfterMap((src, dest) =>
                {
                    FillDataSetFields(src.ConsultaTasaInteresResult, ref dest);
                });
        }

        #endregion

        #region Mapeo Helpers
        private DataSet TryConvertToDataSet(object source)
        {
            if (source is DataSet ds)
            {
                // Si ya es un DataSet, lo retornamos directamente
                return ds;
            }
            var dataSet = new DataSet();
            if (source is WS_ContratacionProductosOnline.ArrayOfXElement arrayOfXElement)
            {
                try
                {
                    // Crear un DataSet para almacenar las tablas

                    // Convertir ArrayOfXElement a un XDocument o tratarlo como XML genérico
                    var xmlString = arrayOfXElement.ToString(); // Convertir el objeto a string XML
                    XDocument xDocument = XDocument.Parse(xmlString);

                    // Iterar sobre los elementos hijos del documento, donde cada uno será una tabla
                    foreach (XElement tableElement in xDocument.Elements())
                    {
                        var dataTable = new DataTable(tableElement.Name.LocalName);
                        bool columnsCreated = false;

                        // Iterar sobre las filas (subelementos del elemento tabla)
                        foreach (XElement rowElement in tableElement.Elements())
                        {
                            var dataRow = dataTable.NewRow();

                            // Iterar sobre las columnas (subelementos de la fila)
                            foreach (XElement columnElement in rowElement.Elements())
                            {
                                if (!columnsCreated)
                                {
                                    // Crear la columna si aún no ha sido creada
                                    if (!dataTable.Columns.Contains(columnElement.Name.LocalName))
                                    {
                                        dataTable.Columns.Add(columnElement.Name.LocalName, typeof(string)); // Puedes ajustar el tipo según sea necesario
                                    }
                                }

                                // Asignar el valor del elemento XML a la columna correspondiente
                                dataRow[columnElement.Name.LocalName] = columnElement.Value;
                            }

                            // Agregar la fila a la tabla
                            dataTable.Rows.Add(dataRow);
                            columnsCreated = true; // Marcar que las columnas han sido creadas
                        }

                        // Agregar la tabla al DataSet
                        dataSet.Tables.Add(dataTable);
                    }

                    return dataSet; // Retornar el DataSet creado
                }
                catch
                {
                    // Si ocurre un error en la conversión, retornar null
                    dataSet = new DataSet();
                }            

            }
            return dataSet;
        }

        private static void FillDataSetFields(WS_ContratacionProductosOnline.ArrayOfXElement arrayOfXElement, ref ConsultaTasaInteresResponseDTO dest)
        {

            XElement xmlNode = arrayOfXElement.Nodes[1] as XElement;
            if (xmlNode != null)
            {
                Diffgram diffgramData = XmlHelper.DeserializeXmlFromXElement(xmlNode);
                try
                {
                    if (diffgramData != null && diffgramData.Informacion != null && diffgramData.Informacion.Resultado != null)
                    {
                        dest.Tasa = diffgramData.Informacion.Resultado.Tasa.ToString();
                        dest.FechaVencimiento = diffgramData.Informacion.Resultado.FechaVencimiento.ToString();
                        dest.AutorizaMargen = diffgramData.Informacion.Resultado.AutorizaMargen.ToString();
                        dest.FechaEmision = diffgramData.Informacion.Resultado.FechaEmision.ToString();
                    }
                    else
                    {
                        dest.CodigoRetorno = diffgramData.Informacion.Estatus.Codigo;
                        dest.MensajeRetorno = diffgramData.Informacion.Estatus.Mensaje;
                    }
                }
                catch (Exception)
                {
                    dest.CodigoRetorno = "999";
                    dest.MensajeRetorno ="Error no manejado en WS";

                }
 

            }
        }
        #endregion

    }
}
