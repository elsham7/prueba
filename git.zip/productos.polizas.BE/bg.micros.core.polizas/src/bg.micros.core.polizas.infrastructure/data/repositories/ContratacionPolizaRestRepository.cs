﻿using bg.micros.core.polizas.application.interfaces.repositories;
using bg.micros.core.polizas.application.models.exeptions;
using bg.micros.core.polizas.domain.entities.simulacion;
using Microsoft.Extensions.Configuration;
using Serilog;
using Newtonsoft.Json;
using Microsoft.Extensions.Caching.Memory;
using System.Data;
using bg.micros.core.polizas.domain.entities.webServices;
using AutoMapper;
using bg.micros.core.polizas.infrastructure.utils;
using WS_ContratacionProductosOnline;

namespace bg.micros.core.polizas.infrastructure.data.repositories
{
    internal class ContratacionPolizaRestRepository : IContratacionPolizaRestRepository
    {
        private readonly IConfiguration _configuration;
        private readonly IMemoryCache _memoryCache;
        private readonly IMapper _mapper;


        public ContratacionPolizaRestRepository(IConfiguration Configuration, IMemoryCache Cache, IMapper Mapper)
        {
            _configuration = Configuration;
            _memoryCache = Cache;
            _mapper = Mapper;
        }

        public async Task<PolizaContratacionDTO> ContratarPoliza(PolizaContratacionDTO request) {

                        WS_ContratacionProductosOnline.WS_ContratacionProductosOnlineSoapClient clienteProductos =
                            new WS_ContratacionProductosOnline.WS_ContratacionProductosOnlineSoapClient(
                                            WS_ContratacionProductosOnline.WS_ContratacionProductosOnlineSoapClient.EndpointConfiguration.WS_ContratacionProductosOnlineSoap,
                                            _configuration["WSContratacionProductosOnlineUrl"]);


            PolizaContratacionDTO response = new PolizaContratacionDTO();
            if (request != null)
            {
                WS_ContratacionProductosOnline.CrearLogicaPolizasAppRequest clienteRequest = new WS_ContratacionProductosOnline.CrearLogicaPolizasAppRequest();
                clienteRequest = _mapper.Map<CrearLogicaPolizasAppRequest>(request);
                WS_ContratacionProductosOnline.CrearLogicaPolizasAppResponse responseWS = await clienteProductos.CrearLogicaPolizasAppAsync(clienteRequest);
                request.CodigoRetorno = responseWS.CodigoRetorno;
                request.MensajeRetorno = responseWS.MensajeRetorno;
                request.Docum = responseWS.docum;
                request.IdExpedienteGenerado = responseWS.idExpedienteGenerado;
            }
            else {
                request= new PolizaContratacionDTO();
                request.CodigoRetorno = "001";
                request.MensajeRetorno = "Error no manejado en WS";
                request.Docum = "";
                request.IdExpedienteGenerado = "";
            }
            return request;
        }
        public async Task<ConsultaTasaInteresResponseDTO> ConsultaTasaInteres(ConsultaTasaInteresDTO request)
        {
            WS_ContratacionProductosOnline.WS_ContratacionProductosOnlineSoapClient clienteProductos =
                new WS_ContratacionProductosOnline.WS_ContratacionProductosOnlineSoapClient(
                                WS_ContratacionProductosOnline.WS_ContratacionProductosOnlineSoapClient.EndpointConfiguration.WS_ContratacionProductosOnlineSoap,
                                _configuration["WSContratacionProductosOnlineUrl"]);

            ConsultaTasaInteresResponseDTO response = new ConsultaTasaInteresResponseDTO();
            if (request != null)
            {
                WS_ContratacionProductosOnline.ConsultaTasaInteresRequest clienteRequest = new WS_ContratacionProductosOnline.ConsultaTasaInteresRequest();
                clienteRequest = _mapper.Map<ConsultaTasaInteresRequest>(request);

                WS_ContratacionProductosOnline.ConsultaTasaInteresResponse responseWS = await clienteProductos.ConsultaTasaInteresAsync(clienteRequest);
                response = _mapper.Map<ConsultaTasaInteresResponseDTO>(responseWS);
            }
            else
            {
                response.CodigoRetorno = "001";
                response.MensajeRetorno = "Error no manejado en WS";
            }
            return response;
        }
    }
}
