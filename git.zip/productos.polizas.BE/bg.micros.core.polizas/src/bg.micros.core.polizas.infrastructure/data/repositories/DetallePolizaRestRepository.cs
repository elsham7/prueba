﻿using AutoMapper;
using bg.micros.core.polizas.application.interfaces.repositories;
using bg.micros.core.polizas.application.models.exeptions;
using bg.micros.core.polizas.domain.entities.datospolizas;
using bg.micros.core.polizas.domain.entities.polizas;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Serilog;
using refPolizasDto = bg.micros.core.polizas.domain.entities.polizas.dataservices;
using refDatosPolizaDto = bg.micros.core.polizas.domain.entities.datospolizas.dataservices;
using Microsoft.Data.SqlClient;
using System.Net;


namespace bg.micros.core.polizas.infrastructure.data.repositories
{
    public class DetallePolizaRestRepository : IDetallePolizaRestRepository, IDisposable
    {
        private readonly IConfiguration _configuration;
        private readonly IMapper _mapper;
        private readonly HttpClient _httpClient;
        private bool _disposed = false;


        public DetallePolizaRestRepository(IConfiguration configuration, IMapper mapper, HttpClient httpClient)
        {
            this._configuration = configuration;
            this._mapper = mapper;
            this._httpClient = httpClient;
        }

        public async Task<ResponseDetallePoliza> ObtenerDetallePoliza(RequestDetallePoliza request)
        {
            var responseDetallePoliza = new ResponseDetallePoliza();
            string StrError = "";
            Log.Information("{Proceso} {identificacion} {numeroDocumento} {direccionIp}", "ObtenerDetallePoliza IN", request.identificacion, request.numeroDocumento, request.direccionIp);

            try
            {
                var url = string.Format("{0}/poliza/v1/detalle", _configuration["DataServicesPolizasUrl"]);
                _httpClient.DefaultRequestHeaders.TryAddWithoutValidation("identificacion", request.identificacion.Trim());
                _httpClient.DefaultRequestHeaders.TryAddWithoutValidation("documento", request.numeroDocumento.Trim());
                HttpResponseMessage response = null;
                string? responseJson = "";
                int _code = 0;
                string strError = string.Empty;

                using (response = await _httpClient.GetAsync(url))
                {
                     responseJson = await response.Content.ReadAsStringAsync();
                    _code = response.StatusCode.GetHashCode();
                    Log.Information("{Proceso} {CodigoRetorno}", "ObtenerDetallePoliza OUT", string.Format("{0}-{1}", _code, response.StatusCode.ToString()));
                }

                if (response.IsSuccessStatusCode)
                {
                    var responseDetallePolizaDto   = ObtenerDetallePolizasDto(responseJson);
                    responseDetallePoliza.detallePoliza = _mapper.Map<ICollection<ResponseDetallePolizaItem>>(responseDetallePolizaDto.data);
                    Log.Information("{Proceso} {Mensaje}", "ObtenerDetallePoliza OUT", "Consulta OK");
                }
                else
                {
                    if (_code == HttpStatusCode.InternalServerError.GetHashCode())
                    {
                        throw new DetallePolizaException("Error de aplicativo", response.RequestMessage.ToString(), _code);
                    }
                    strError = "ObtenerAutorizacionSobregiro " + response.ReasonPhrase;
                    Log.Error("{Proceso} {Trama} ", strError, string.Format("{0} {1} {2} {3} {4}", "Codigo del error :", response.StatusCode, ", Motivo del error :", response.ReasonPhrase, (string.IsNullOrEmpty(responseJson)?"":"Error:"+responseJson)));
                    throw new DetallePolizaException(response.ReasonPhrase, string.Format("{0}", (string.IsNullOrEmpty(responseJson) ? "" : "Error:" + responseJson)) , _code);
                }

                if (response == null)
                {
                    throw new DetallePolizaException(string.Format("No existe datos con la identificacion:{0}, numeroDocumento:{1}", request.identificacion, request.numeroDocumento));
                }
            }
            catch (HttpRequestException re)
            {
                StrError = "Error HTTP al consultar detalle poliza";
                Log.Error("{Proceso} {Trama} ", StrError, re.Message);
                throw new DetallePolizaException(StrError, re.StackTrace, 500);
            }
            catch (TimeoutException te)
            {
                StrError = "ObtenerDetallePoliza TimeoutException";
                Log.Error("{Proceso} {Trama} ", StrError, te.Message);
                throw new DetallePolizaException(StrError, te.StackTrace, 500);
            }
            return responseDetallePoliza;
        }

        public async Task<DatosPolizas> ObtenerDatosPolizaRestRep(DatosPolizasRequest request)
        { 
            var responseDatosPoliza = new DatosPolizas();
            string StrError = "";
            Log.Information("{Proceso} {agencia} {tipoDocumento} {nroDocumento} {eliminacion}", "ObtenerDatosPolizaRestRep IN", request.agencia, request.tipo, request.documento);

            try
            {
             var url = _configuration["InfraConfig:DataServices:DatosPolizas:Url"];
             var timeout = Convert.ToInt32(_configuration["InfraConfig:DataServices:DatosPolizas:TimeOut"]);

                _httpClient.DefaultRequestHeaders.TryAddWithoutValidation("agencia", request.agencia);
                _httpClient.DefaultRequestHeaders.TryAddWithoutValidation("tipo", request.tipo);
                _httpClient.DefaultRequestHeaders.TryAddWithoutValidation("documento", request.documento);
                _httpClient.Timeout = TimeSpan.FromMilliseconds(timeout);

                using (var response = await _httpClient.GetAsync(url))
                {
                    response.EnsureSuccessStatusCode();
                    var responseJson = await response.Content.ReadAsStringAsync();
                    var responseDatosPolizaDto = ObtenerDatosPolizasDto(responseJson);
                    responseDatosPoliza = _mapper.Map<DatosPolizas>(responseDatosPolizaDto.data);                             
                    Log.Information("{Proceso} {Mensaje}", "ObtenerDatosPolizaRestRep OUT", "Consulta OK");
                }
            }
            catch (HttpRequestException re)
            {
                StrError = "Error HTTP al consultar datos poliza";
                Log.Error("{Proceso} {Trama} ", StrError, re.Message);
                throw new DatosPolizaException(StrError, re.StackTrace, 500);
            }
            catch (TimeoutException te)
            {
                StrError = "ObtenerDatosPolizaRestRep TimeoutException";
                Log.Error("{Proceso} {Trama} ", StrError, te.Message);
                throw new DatosPolizaException(StrError, te.StackTrace, 500);
            }
            catch (Exception ex)
            {
                StrError = "ObtenerDatosPolizaRestRep Exception";                                                                                                                                                                                                                                      
                Log.Error("{Proceso} {Trama} ", StrError, ex.Message);
                throw new DatosPolizaException(StrError, ex.StackTrace, 500);
            }
            return responseDatosPoliza;
        }



        #region Metodos Privados
        private refPolizasDto.Respuesta ObtenerDetallePolizasDto(string responseJson)
        {
            return  JsonConvert.DeserializeObject<refPolizasDto.Respuesta>(responseJson, new JsonSerializerSettings
            {
                TypeNameHandling = TypeNameHandling.None
            });
        }

        private refDatosPolizaDto.Respuesta ObtenerDatosPolizasDto(string responseJson)
        {
            return JsonConvert.DeserializeObject<refDatosPolizaDto.Respuesta>(responseJson, new JsonSerializerSettings
            {
                TypeNameHandling = TypeNameHandling.None
            });
        }

        #endregion

        #region IDisposable

        protected virtual void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                if (_httpClient != null)
                {
                    _httpClient.Dispose();
                }
            }

            _disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        ~DetallePolizaRestRepository()
        {
            Dispose(false);
        }

        #endregion
    }
}
