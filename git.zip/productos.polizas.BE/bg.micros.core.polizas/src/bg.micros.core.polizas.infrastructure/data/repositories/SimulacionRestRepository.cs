﻿using bg.micros.core.polizas.application.interfaces.repositories;
using bg.micros.core.polizas.application.models.exeptions;
using bg.micros.core.polizas.domain.entities.simulacion;
using Microsoft.Extensions.Configuration;
using Serilog;
using Newtonsoft.Json;
using Microsoft.Extensions.Caching.Memory;

namespace bg.micros.core.polizas.infrastructure.data.repositories
{
    internal class SimulacionRestRepository : ISimulacionRestRepository
    {
        private readonly IConfiguration _configuration;
        private readonly IMemoryCache _memoryCache;

        public SimulacionRestRepository(IConfiguration Configuration, IMemoryCache Cache)
        {
            _configuration = Configuration;
            _memoryCache = Cache;
        }

        public async Task<ResponseTasaBipf> ConsultaTasaBIPF(string fechaTasa)
        {
            Log.Information("{Proceso} {Descripcion} - {Fecha}", "ConsultaTasaBIPF", "Consulta la tabla de tasas Bipf en ORDS y lo almacena en cache", fechaTasa);

            ResponseTasaBipf? responseOrds = null;
            var client = new HttpClient();
            var response = new HttpResponseMessage();
            string url = string.Format("{0}/poliza/v1/tasas", _configuration["DataServicesPolizasUrl"]);
            client.DefaultRequestHeaders.Clear();
            client.DefaultRequestHeaders.Add("fecha", fechaTasa);
            client.DefaultRequestHeaders.Add("clave", _configuration["TipoTasaORDS"]);


            response = await client.GetAsync(url);

            if (response.IsSuccessStatusCode)
            {
                string responseBody = await response.Content.ReadAsStringAsync();
                responseOrds = JsonConvert.DeserializeObject<ResponseTasaBipf?>(responseBody, new JsonSerializerSettings
                {
                    TypeNameHandling = TypeNameHandling.None
                });

                if (responseOrds != null && responseOrds.Data != null && responseOrds.Data.Count > 0)
                { 
                    string ordsCacheKey = _configuration["BipfORDSCacheKey"] + fechaTasa;
                    _memoryCache.Set<ResponseTasaBipf>(ordsCacheKey, responseOrds, new DateTimeOffset(DateTime.Now.AddMinutes(double.Parse(_configuration["ORDSPolizaMemoryCache"]))));
                }
            }
            else
            {
                if ((int)response.StatusCode == 404)
                    throw new PersonasException("Error de aplicativo", "Registro no encontrado.", 204);
                string messageResponse = string.Empty;

                messageResponse = await response.Content.ReadAsStringAsync();

                throw new PersonasException("Error de aplicativo", messageResponse.ToString(), ((int)response.StatusCode));
            }

            if (responseOrds == null)
                throw new ContratoContactoException("Error de aplicativo", "Tasa no encontrada.", 204);
           
            Log.Information("{Proceso} {Descripcion} - {Fecha} - {StatusCode}", "ConsultaTasaBIPF", "Consulta la tabla de tasas Bipf en ORDS y lo almacena en cache", fechaTasa, (int)response.StatusCode);
            return responseOrds;
        }
 
    }
}
