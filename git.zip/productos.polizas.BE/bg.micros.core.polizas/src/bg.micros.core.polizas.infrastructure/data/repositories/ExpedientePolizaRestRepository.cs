﻿using bg.micros.core.polizas.application.interfaces.repositories;
using bg.micros.core.polizas.application.models.exeptions;
using bg.micros.core.polizas.domain.entities.simulacion;
using Microsoft.Extensions.Configuration;
using Serilog;
using Newtonsoft.Json;
using Microsoft.Extensions.Caching.Memory;
using System.Data;
using bg.micros.core.polizas.domain.entities.webServices;
using AutoMapper;
using bg.micros.core.polizas.infrastructure.utils;

namespace bg.micros.core.polizas.infrastructure.data.repositories
{
    internal class ExpedientePolizaRestRepository : IExpedientePolizaRestRepository
    {
        private readonly IConfiguration _configuration;
        private readonly IMemoryCache _memoryCache;
        private readonly IMapper _mapper;   

        private WS_ExpedientePoliza.ServicioPolizasSoapClient cliente =
              new WS_ExpedientePoliza.ServicioPolizasSoapClient(WS_ExpedientePoliza.ServicioPolizasSoapClient.EndpointConfiguration.ServicioPolizasSoap, "_config.Value.WS_ContratacionProductos.Url");

        public ExpedientePolizaRestRepository(IConfiguration Configuration, IMemoryCache Cache, IMapper Mapper)
        {
            _configuration = Configuration;
            _memoryCache = Cache;
            _mapper = Mapper;          
        }

        public async Task<DataSet> consultarInformacionAdicionalPolizas(GeneralCamposDto genCampos)
        {
            DataSet responseDs = new DataSet();
            InformacionAdicionalPolizaResponseDTO response = new InformacionAdicionalPolizaResponseDTO();
             
            if (genCampos != null && genCampos.LstCampos!= null) { 
                WS_ExpedientePoliza.consultarInformacionAdicionalPolizasRequest clienteRequest = new WS_ExpedientePoliza.consultarInformacionAdicionalPolizasRequest();
                clienteRequest.GenCmp.lstCampos = _mapper.Map<WS_ExpedientePoliza.Campo[]>(genCampos.LstCampos);

                WS_ExpedientePoliza.consultarInformacionAdicionalPolizasResponse responseWS = await cliente.consultarInformacionAdicionalPolizasAsync(clienteRequest);
                responseDs = PrimitiveDataUtils.XMLArrayToDataSet(responseWS.GenCmp.resultadoConsultas, "DataSet");

            }      

            return responseDs;
        }

    }
}
