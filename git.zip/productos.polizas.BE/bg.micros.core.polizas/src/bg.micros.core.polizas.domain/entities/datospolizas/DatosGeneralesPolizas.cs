﻿using System;
using System.Collections.Generic;
using System.Text;

namespace bg.micros.core.polizas.domain.entities.datospolizas
{
    public class DatosGeneralesPolizas
    {
        public string? identificacion { get; set; }
        public int cliente { get; set; }
        public int numeroPoliza { get; set; }
        public string? tipoInversion { get; set; }
        public int capital { get; set; }
        public double tasa { get; set; }
        public int plazoDias { get; set; }
        public double valorInteresGanado { get; set; }
        public int impuestoPorc_2 { get; set; }
        public double valImpuesto { get; set; }
        public double netoRecibir { get; set; }
        public string? canal { get; set; }
        public int fechaEmision { get; set; }
        public int fechaVcto { get; set; }
        public int fechaRevision { get; set; }
        public int agencia { get; set; }
        public int periodosPagoint { get; set; }
        public string? revisor { get; set; }
        public int cuentaPagoint { get; set; }
        public int clienteAnterior { get; set; }
        public string? observacion { get; set; }
        public string? ruteoApro1 { get; set; }
        public string? ruteoApro2 { get; set; }
        public string? ruteoApro3 { get; set; }
        public string? ruteoApro4 { get; set; }
        public string? opidRevision { get; set; }
        public string? opidImpresion { get; set; }
        public string? terminalImpresion { get; set; }
        public int fechaImpresion { get; set; }
        public int horaImpresion { get; set; }
        public int numeroImpresion { get; set; }
        public string? nombreBeneficiario { get; set; }
        public string? renovacionautomatica { get; set; }
        public List<FormaPago> formaPago { get; set; }
        public List<FormaCan> formaCan { get; set; }
    }
}
