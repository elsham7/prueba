﻿using System;
using System.Collections.Generic;
using System.Text;

namespace bg.micros.core.polizas.domain.entities.datospolizas.dataservices
{

    public class Respuesta
    {
        public DataDatosPolizas? data { get; set; }
    }

    public class DataDatosPolizas
    {
        public DatosGeneralesPolizas? datos_generales_poliza { get; set; }
    }

    public class DatosGeneralesPolizas
    {
        public string? identificacion { get; set; }
        public int? cliente { get; set; }
        public int? numero_poliza { get; set; }
        public string? tipo_inversion { get; set; }
        public int? capital { get; set; }
        public double? tasa { get; set; }
        public int? plazo_dias { get; set; }
        public double? valor_interes_ganado { get; set; }
        public int? impuesto_porc_2 { get; set; }
        public double? val_impuesto { get; set; }
        public double? neto_recibir { get; set; }
        public string? canal { get; set; }
        public int? fecha_emision { get; set; }
        public int? fecha_vcto { get; set; }
        public int? fecha_revision { get; set; }
        public int? agencia { get; set; }
        public int? periodos_pagoint { get; set; }
        public string? revisor { get; set; }
        public int? cuenta_pagoint { get; set; }
        public int? cliente_anterior { get; set; }
        public string? observacion { get; set; }
        public string? ruteo_apro1 { get; set; }
        public string? ruteo_apro2 { get; set; }
        public string? ruteo_apro3 { get; set; }
        public string? ruteo_apro4 { get; set; }
        public string? opid_revision { get; set; }
        public string? opid_impresion { get; set; }
        public string? terminal_impresion { get; set; }
        public int? fecha_impresion { get; set; }
        public int? hora_impresion { get; set; }
        public int? numero_impresion { get; set; }
        public string? nombre_beneficiario { get; set; }
        public string? renovacionautomatica { get; set; }

        public List<FormaPagar>? forma_pago { get; set; }
        public List<FormaCancelar>? forma_can { get; set; }
    }

    public class FormaPagar
    {
        public string? forma_de_pago { get; set; }
        public int? numero_de_cuenta { get; set; }
        public double? valor { get; set; }
    }

    public class FormaCancelar
    {
        public string forma_de_cancelar { get; set; }
        public int numero_de_cuenta { get; set; }
        public double? valor { get; set; }
    }

}
