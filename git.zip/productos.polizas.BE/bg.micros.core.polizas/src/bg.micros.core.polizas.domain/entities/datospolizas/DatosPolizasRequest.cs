﻿using System;
using System.Collections.Generic;
using System.Text;

namespace bg.micros.core.polizas.domain.entities.datospolizas
{
    public class DatosPolizasRequest
    {
        public string? agencia { get; set; }
        public string? documento { get; set; }
        public string? tipo { get; set; }
    }
}
