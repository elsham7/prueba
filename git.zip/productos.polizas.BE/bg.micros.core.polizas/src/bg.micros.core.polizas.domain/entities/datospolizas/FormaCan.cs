﻿using System;
using System.Collections.Generic;
using System.Text;

namespace bg.micros.core.polizas.domain.entities.datospolizas
{
    public class FormaCan
    {
        public string? formaDeCancelar { get; set; }
        public int numeroDeCuenta { get; set; }
        public double valor { get; set; }
    }
}
