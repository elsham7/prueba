﻿using System;
using System.Collections.Generic;
using System.Text;

namespace bg.micros.core.polizas.domain.entities.datospolizas
{
    public class FormaPago
    {
        public string? formaDePago { get; set; }
        public int numeroDeCuenta { get; set; }
        public double  valor { get; set; }
    }
}
