﻿using bg.micros.core.polizas.domain.entities.datospolizas.dataservices;
using System;
using System.Collections.Generic;
using System.Text;

namespace bg.micros.core.polizas.domain.entities.datospolizas
{
    public class DatosPolizas
    {
        public DatosGeneralesPolizas? datosGeneralesPoliza { get; set; }
    }
}
