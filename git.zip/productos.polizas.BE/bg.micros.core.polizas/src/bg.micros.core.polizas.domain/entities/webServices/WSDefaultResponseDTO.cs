﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace bg.micros.core.polizas.domain.entities.simulacion
{
    public class WSDefaultResponseDTO
    {
        
        public DataSet? Data { set; get; }
    }
}
