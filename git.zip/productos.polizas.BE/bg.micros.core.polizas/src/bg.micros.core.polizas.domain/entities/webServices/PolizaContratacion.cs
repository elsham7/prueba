﻿using System;
using System.Collections.Generic;
using System.Text;

namespace bg.micros.core.polizas.domain.entities.webServices
{
    public class PolizaContratacionDTO
    {
        public string? TipoIdentificacion { get; set; }
        public string? NumIdentificacion { get; set; }
        public string? IdProducto { get; set; }
        public string? IdCanal { get; set; }
        public string? Capital { get; set; }
        public string? Plazo { get; set; }
        public string? TasaInteres { get; set; }
        public string? InteresRecibir { get; set; }
        public string? MargenTasa { get; set; }
        public string? TasaSolicitada { get; set; }
        public string? MargenTasaSolicitada { get; set; }
        public string? ImpuestoCobrado { get; set; }
        public string? InteresNeto { get; set; }
        public string? InteresCobrado { get; set; }
        public string? MontoNetoRecibir { get; set; }
        public string? PorcentajeImpuesto { get; set; }
        public string? FechaEmision { get; set; }
        public string? FechaVencimiento { get; set; }
        public string? RenovacionAut { get; set; }
        public string? NumDocumento { get; set; }
        public string? OpidOficialCli { get; set; }
        public string? OpidOficialIng { get; set; }
        public string? PolizaAnterior { get; set; }
        public string? Estado { get; set; }
        public string? AutorizaMargen { get; set; }
        public string? NumeroCuenta { get; set; }
        public string? TipoCuenta { get; set; }
        public string? TipoPoliza { get; set; }
        public string? Periodicidad { get; set; }
        public string? IdModulo { get; set; }
        public string? idFormulario { get; set; }
        public string? StrNumTrazabilidad { get; set; }
        public string? Usuario { get; set; }
        public string? StrIP { get; set; }
        public string? Docum { get; set; }
        public string? IdExpedienteGenerado { get; set; }
        public string? CodigoRetorno { get; set; }
        public string? MensajeRetorno { get; set; }
        public string? Observaciones { get; set; }

        public List<string> ValidarCampos()
        {
            List<string> errores = new List<string>();

            // Validaciones de string vacíos
        
            if (string.IsNullOrWhiteSpace(TipoIdentificacion)) errores.Add("El campo TipoIdentificacion es requerido.");
            if (string.IsNullOrWhiteSpace(NumIdentificacion)) errores.Add("El campo NumIdentificacion es requerido.");
            if (string.IsNullOrWhiteSpace(IdProducto)) errores.Add("El campo IdProducto es requerido.");
            if (string.IsNullOrWhiteSpace(IdCanal)) errores.Add("El campo IdCanal es requerido.");
            if (string.IsNullOrWhiteSpace(Capital)) errores.Add("El campo Capital es requerido.");
            if (string.IsNullOrWhiteSpace(Plazo)) errores.Add("El campo Plazo es requerido.");
            if (string.IsNullOrWhiteSpace(TasaInteres)) errores.Add("El campo TasaInteres es requerido.");
            if (string.IsNullOrWhiteSpace(InteresRecibir)) errores.Add("El campo InteresRecibir es requerido.");
            if (string.IsNullOrWhiteSpace(MargenTasa)) errores.Add("El campo MargenTasa es requerido.");
            if (string.IsNullOrWhiteSpace(TasaSolicitada)) errores.Add("El campo TasaSolicitada es requerido.");
            if (string.IsNullOrWhiteSpace(MargenTasaSolicitada)) errores.Add("El campo MargenTasaSolicitada es requerido.");
            if (string.IsNullOrWhiteSpace(ImpuestoCobrado)) errores.Add("El campo ImpuestoCobrado es requerido.");
            if (string.IsNullOrWhiteSpace(InteresNeto)) errores.Add("El campo InteresNeto es requerido.");
            if (string.IsNullOrWhiteSpace(InteresCobrado)) errores.Add("El campo InteresCobrado es requerido.");
            if (string.IsNullOrWhiteSpace(MontoNetoRecibir)) errores.Add("El campo MontoNetoRecibir es requerido.");
            if (string.IsNullOrWhiteSpace(PorcentajeImpuesto)) errores.Add("El campo PorcentajeImpuesto es requerido.");
            if (string.IsNullOrWhiteSpace(FechaEmision)) errores.Add("El campo FechaEmision es requerido.");
            if (string.IsNullOrWhiteSpace(FechaVencimiento)) errores.Add("El campo FechaVencimiento es requerido.");
            if (string.IsNullOrWhiteSpace(RenovacionAut)) errores.Add("El campo RenovacionAut es requerido.");
            if (string.IsNullOrWhiteSpace(NumDocumento)) errores.Add("El campo NumDocumento es requerido.");
            if (string.IsNullOrWhiteSpace(OpidOficialCli)) errores.Add("El campo OpidOficialCli es requerido.");
            if (string.IsNullOrWhiteSpace(OpidOficialIng)) errores.Add("El campo OpidOficialIng es requerido.");
            if (string.IsNullOrWhiteSpace(PolizaAnterior)) errores.Add("El campo PolizaAnterior es requerido.");
            if (string.IsNullOrWhiteSpace(Estado)) errores.Add("El campo Estado es requerido.");
            if (string.IsNullOrWhiteSpace(AutorizaMargen)) errores.Add("El campo AutorizaMargen es requerido.");
            if (string.IsNullOrWhiteSpace(NumeroCuenta)) errores.Add("El campo NumeroCuenta es requerido.");
            if (string.IsNullOrWhiteSpace(TipoCuenta)) errores.Add("El campo TipoCuenta es requerido.");
            if (string.IsNullOrWhiteSpace(TipoPoliza)) errores.Add("El campo TipoPoliza es requerido.");
            if (string.IsNullOrWhiteSpace(Periodicidad)) errores.Add("El campo Periodicidad es requerido.");
            if (string.IsNullOrWhiteSpace(IdModulo)) errores.Add("El campo IdModulo es requerido.");
            if (string.IsNullOrWhiteSpace(idFormulario)) errores.Add("El campo idFormulario es requerido.");
            if (string.IsNullOrWhiteSpace(StrNumTrazabilidad)) errores.Add("El campo StrNumTrazabilidad es requerido.");
            if (string.IsNullOrWhiteSpace(Usuario)) errores.Add("El campo Usuario es requerido.");
            if (string.IsNullOrWhiteSpace(StrIP)) errores.Add("El campo StrIP es requerido.");
            if (string.IsNullOrWhiteSpace(Observaciones)) errores.Add("El campo Observaciones es requerido.");
            
            ValidarCampoNumerico(Plazo, "Plazo", errores);
            ValidarCampoNumerico(Capital, "Capital", errores);
            return errores;
        }

        private void ValidarCampoNumerico(string? valor, string nombreCampo, List<string> errores)
        {
            if (!string.IsNullOrWhiteSpace(valor))
            {
                if (decimal.TryParse(valor, out decimal valorDecimal))
                {
                    if (valorDecimal <= 0)
                    {
                        errores.Add($"El campo {nombreCampo} debe ser mayor a 0.");
                    }
                }
                else
                {
                    errores.Add($"El campo {nombreCampo} debe ser un valor numérico.");
                }
            }
            else
            {
                errores.Add($"El campo {nombreCampo} es requerido.");
            }
        }

    }
}
