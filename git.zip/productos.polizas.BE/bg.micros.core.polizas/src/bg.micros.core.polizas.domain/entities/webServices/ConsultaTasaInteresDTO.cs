﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace bg.micros.core.polizas.domain.entities.webServices
{

    public class 
        DTO
    {
        /// <summary>
        /// </summary>
        /// <example>C</example>
        public string TipoIdentificacion { get; set; }
        /// <summary>
        /// </summary>
        /// <example>0922614821</example>
        public string NumeroIdentificacion { get; set; }
        /// <summary>
        /// </summary>
        /// <example>10000</example>
        public string Monto { get; set; }
        /// <summary>
        /// </summary>
        /// <example>156</example>
        public string Plazo { get; set; }
        /// <summary>
        /// </summary>
        /// <example>USD</example>
        public string Moneda { get; set; }
        /// <summary>
        /// </summary>
        /// <example>20241113</example>
        public string FechaInversion { get; set; }
        /// <summary>
        /// </summary>
        /// <example>S</example>
        public string CalculoTasa { get; set; }
        /// <summary>
        /// </summary>
        /// <example>1</example>
        public string IdFormulario { get; set; }
        /// <summary>
        /// </summary>
        /// <example>1</example>
        public string IdModulo { get; set; }
        /// <summary>
        /// </summary>
        /// <example>CARMIJOS</example>
        public string StrUsuario { get; set; }


        public ConsultaTasaInteresDTO(
            string tipoIdentificacion,
            string numeroIdentificacion,
            string monto,
            string plazo,
            string moneda,
            string fechaInversion,
            string calculoTasa,
            string idFormulario,
            string idModulo,
            string strUsuario)
        {
            TipoIdentificacion = tipoIdentificacion;
            NumeroIdentificacion = numeroIdentificacion;
            Monto = monto;
            Plazo = plazo;
            Moneda = moneda;
            FechaInversion = fechaInversion;
            CalculoTasa = calculoTasa;
            IdFormulario = idFormulario;
            IdModulo = idModulo;
            StrUsuario = strUsuario;
        }

        public List<string> ValidarCampos()
        {
            List<string> errores = new List<string>();

            if (string.IsNullOrWhiteSpace(TipoIdentificacion) || string.IsNullOrEmpty(TipoIdentificacion))
                errores.Add("El campo TipoIdentificacion es obligatorio.");
            else if (string.IsNullOrWhiteSpace(NumeroIdentificacion) || string.IsNullOrEmpty(NumeroIdentificacion))
                errores.Add("El campo NumeroIdentificacion es obligatorio.");
            else if (string.IsNullOrWhiteSpace(Monto) || string.IsNullOrEmpty(Monto))
                errores.Add("El campo Monto es obligatorio.");
            else if (string.IsNullOrWhiteSpace(Plazo) || string.IsNullOrEmpty(Plazo))
                errores.Add("El campo Plazo es obligatorio.");
            else if (string.IsNullOrWhiteSpace(Moneda) || string.IsNullOrEmpty(Moneda))
                errores.Add("El campo Moneda es obligatorio.");
            else if (string.IsNullOrWhiteSpace(FechaInversion) || string.IsNullOrEmpty(FechaInversion))
                errores.Add("El campo FechaInversion es obligatorio.");
            else if (string.IsNullOrWhiteSpace(CalculoTasa) || string.IsNullOrEmpty(CalculoTasa))
                errores.Add("El campo CalculoTasa es obligatorio.");
            else if (string.IsNullOrWhiteSpace(IdFormulario) || string.IsNullOrEmpty(IdFormulario))
                errores.Add("El campo IdFormulario es obligatorio.");
            else if (string.IsNullOrWhiteSpace(IdModulo) || string.IsNullOrEmpty(IdModulo))
                errores.Add("El campo IdModulo es obligatorio.");
            else if (string.IsNullOrWhiteSpace(StrUsuario) || string.IsNullOrEmpty(StrUsuario))
                errores.Add("El campo StrUsuario es obligatorio.");

            return errores;
        }
    }

    public class ConsultaTasaInteresResponseDTO
    {
        public string CodigoRetorno { get; set; }
        public string MensajeRetorno { get; set; }
        public string Tasa { get; set; }
        public string FechaVencimiento { get; set; }
        public string AutorizaMargen { get; set; }
        public string FechaEmision { get; set; }

    }


    [XmlRoot(ElementName = "diffgram", Namespace = "urn:schemas-microsoft-com:xml-diffgram-v1")]
    public class Diffgram
    {
        [XmlElement(ElementName = "INFORMACION", Namespace = "")]
        public Informacion Informacion { get; set; }
    }

    public class Informacion
    {
        [XmlElement(ElementName = "ESTATUS")]
        public Estatus Estatus { get; set; }

        [XmlElement(ElementName = "RESULTADO")]
        public Resultado Resultado { get; set; }
    }

    public class Estatus
    {
        [XmlElement(ElementName = "CODIGO")]
        public string Codigo { get; set; }

        [XmlElement(ElementName = "MENSAJE")]
        public string Mensaje { get; set; }

        [XmlElement(ElementName = "ERROR")]
        public string Error { get; set; }
    }

    public class Resultado
    {
        [XmlElement(ElementName = "MENSAJE")]
        public string Mensaje { get; set; }

        [XmlElement(ElementName = "TASA")]
        public int Tasa { get; set; }

        [XmlElement(ElementName = "FECHA-VENCIMIENTO")]
        public string FechaVencimiento { get; set; }

        [XmlElement(ElementName = "AUTORIZA-MARGEN")]
        public string AutorizaMargen { get; set; }

        [XmlElement(ElementName = "FECHA-EMISION")]
        public string FechaEmision { get; set; }

        [XmlElement(ElementName = "FILLER")]
        public string Filler { get; set; }
    }



}
