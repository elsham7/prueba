﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;
using System.Data;


namespace bg.micros.core.polizas.domain.entities.webServices
{
    public class GeneralCamposDto
    {
        public List<CampoDto>? LstCampos { get; set; }
        public string? CodigoError { get; set; }
        public string? MensajeError { get; set; }
        public DataSet? ResultadoConsultas { get; set; }
        public int Formulario { get; set; }
        public List<CampoDto>? ListadoCampos { get; set; }
    }


    public class CampoDto
    {
        public string? TipoDato { get; set; }
        public string? ValorDato { get; set; }
        public int? TamanioDato { get; set; }
        public string? NombreDato { get; set; }
    }

    public class InformacionAdicionalPolizasRequest
    {
        public string Opcion { get; set; } = "14";             
        public string IdProducto { get; set; } = "0";
        public string IdPersona { get; set; } = "0925971699";
        public string CorreoCliente { get; set; } = "jjativa@outlook.com";
        public string TelefonoCliente { get; set; } = "0981584977";          
        public string IdModulo { get; set; } = "298";           
        public string IdFormulario { get; set; } = "0";         
        public string NumTrazabilidad { get; set; } = "0";
        public string UsuarioGestor { get; set; } = "NEOWEB";
        public string DireccionIP { get; set; } = "172.26.60.71";
           
    }

    public class InformacionAdicionalPolizaResponseDTO
    {
        public string CodigoRetorno { get; set; }
        public string MensajeRetorno { get; set; }
        public DataSet? Data { get; set; }
    }

}

