﻿using System;
using System.Collections.Generic;
using System.Text;

namespace bg.micros.core.polizas.domain.entities.simulacion
{
    public class ConsultaSimulacionRequest
    {
        // <summary>
        /// Monto de la inversión.
        /// </summary>
        /// <example>10000.00</example>
        public decimal Monto { get; set; }

        /// <summary>
        /// Plazo de la inversión en días.
        /// </summary>
        /// <example>360</example>
        public int Plazo { get; set; }

        /// <summary>
        /// Tipo de plazo ("M":Mes, "D":Dias).
        /// </summary>
        /// <example>"M"</example>
        public string? TipoPlazo { get; set; }

        /// <summary>
        /// Generar Recomendaciones (true, false).
        /// </summary>
        /// <example>true</example>
        public bool GenerarRecomendaciones { get; set; } = false;
        /// <summary>
        /// Monto Acumuladoen polizas activas.
        /// </summary>
        /// <example>0</example>

        public decimal MontoAcumulado { get; set; } = 0M;

    }
}
