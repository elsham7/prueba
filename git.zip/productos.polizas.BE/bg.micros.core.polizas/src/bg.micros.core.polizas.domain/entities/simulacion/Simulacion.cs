﻿namespace bg.micros.core.polizas.domain.entities.simulacion
{
    public class Simulacion
    {
        public int Indice { get; set; }
        public decimal Monto { get; set; }
        public int Plazo { get; set; }
        public string? TipoDePlazo { get; set; }
        public decimal TasaDeInteres { get; set; }
        public decimal InteresGenerado { get; set; }
        public decimal Impuesto { get; set; }
        public decimal MontoFinal { get; set; }
        public string? FechaVencimiento { get; set; }
        public decimal TasaInteresOriginal { get; set; } = 0;
        public bool SimulacionCumulo { get; set; } = false;
    }
}