﻿using System;
using System.Collections.Generic;
using System.Text;

namespace bg.micros.core.polizas.domain.entities.simulacion
{

    public class TasaBipfItem
    {
        public int Desde { get; set; }
        public int Hasta { get; set; }
        public decimal To_1_30_d { get; set; }
        public decimal To_31_59_d { get; set; }
        public decimal To_60_89_d { get; set; }
        public decimal To_90_119_d { get; set; }
        public decimal To_120_179_d { get; set; }
        public decimal To_180_270_d { get; set; }
        public decimal To_271_360_d { get; set; }
        public decimal To_361_99999_d { get; set; }
    }


    public class ResponseTasaBipf
    {
        public string? Traceid { get; set; }
        public List<TasaBipfItem>? Data { get; set; }
    }

}
