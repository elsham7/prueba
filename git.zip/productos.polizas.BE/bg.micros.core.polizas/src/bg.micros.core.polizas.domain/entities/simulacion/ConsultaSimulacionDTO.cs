﻿using System;
using System.Collections.Generic;
using System.Text;

namespace bg.micros.core.polizas.domain.entities.simulacion
{
    public class ConsultaSimulacionDTO
    {
        public List<Simulacion>? SimulacionList { set; get; }
    }
}
