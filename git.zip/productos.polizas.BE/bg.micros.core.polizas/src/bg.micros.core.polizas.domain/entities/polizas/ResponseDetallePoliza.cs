﻿using System.Collections.Generic;

namespace bg.micros.core.polizas.domain.entities.polizas
{
    public class ResponseDetallePoliza
    {
        public ICollection<ResponseDetallePolizaItem>? detallePoliza { get; set; }
    }
}
