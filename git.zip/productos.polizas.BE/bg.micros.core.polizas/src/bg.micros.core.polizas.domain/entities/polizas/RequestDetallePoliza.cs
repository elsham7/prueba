﻿using System;
using System.Collections.Generic;
using System.Text;

namespace bg.micros.core.polizas.domain.entities.polizas
{
    public class RequestDetallePoliza
    {
        public string? identificacion {  get; set; }
        public string? numeroDocumento { get; set; }
        public string? direccionIp { get; set; }
    }
}
