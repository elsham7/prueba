﻿using System;
using System.Collections.Generic;
using System.Text;

namespace bg.micros.core.polizas.domain.entities.polizas
{
    public class ResponseDetallePolizaItem
    {
        public string? marcaRenovacion { get; set; }
        public string? descripcionRenovacion { get; set; }
        public int codigoPeriocidad { get; set; }
        public string? descripcionPeriocidad { get; set; }
        public string? origenPoliza { get; set; }
        public string? agencia { get; set; }
        public string? documento { get; set; }
        public string? titular { get; set; }
        public string? beneficiario { get; set; }
        public string? fechaEmision { get; set; }
        public string? plazo { get; set; }
        public string? fechaVencimiento { get; set; }
        public double capital { get; set; }
        public double tasaInteres { get; set; }
        public double interesesCobrados { get; set; }
        public double interesesPorCobrar { get; set; }
        public string fechaProximoCobroIntereses { get; set; }
        public double impuestosCobrados { get; set; }
        public double impuestosPorCobrar { get; set; }
        public double monto { get; set; }
        public string? tipoInversion { get; set; }
        public string? status { get; set; }
        public string? identificacion { get; set; }
        public string? codigoDactilar { get; set; }
        public string? codigoRetorno { get; set; }
    }
}
