﻿using System;
using System.Collections.Generic;
using System.Text;

namespace bg.micros.core.polizas.domain.entities.polizas.dataservices
{
    public class Respuesta
    {
        public string traceid { get; set; }
        public List<Data> data { get; set; }
    }

    public class Data
    {
        public string? marca_renovacion { get; set; }
        public string? descripcion_renovacion { get; set; }
        public int codigo_periocidad { get; set; }
        public string? descripcion_periocidad { get; set; }
        public string? beneficiario { get; set; }
        public string? origen_poliza { get; set; }
        public string? agencia { get; set; }
        public string? documento { get; set; }
        public string? titular { get; set; }
        public int? fecha_emision { get; set; }
        public string? plazo { get; set; }
        public int? fecha_vencimiento { get; set; }
        public int capital { get; set; }
        public double tasa_interes { get; set; }
        public double interes_cobrado { get; set; }
        public double interes_x_cobrar { get; set; }
        public double impuesto_cobrado { get; set; }
        public double impuesto_x_cobrar { get; set; }
        public string? fecha_proximo_cobro_intereses { get; set; }
        public double monto { get; set; }
        public string? tipo_inversion { get; set; }
        public string? pzk_status { get; set; }
        public string? a { get; set; }
        public string? identificacion { get; set; }
        public string? codigoretorno { get; set; }
    }
}
