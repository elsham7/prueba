﻿using bg.micros.core.polizas.application.interfaces.services;
using bg.micros.core.polizas.application.services;
using Microsoft.Extensions.DependencyInjection;

namespace bg.micros.core.polizas.application.ioc
{
    public static class DependencyInyection
    {

        public static IServiceCollection AddApplication(this IServiceCollection services)
        {
            services.AddScoped<IDetallePolizaRepository, DetallePolizaRepository>();
            services.AddScoped<ISimulacionRepository, SimulacionRepository>();
            services.AddScoped<IContratacionPolizaRepository, ContratacionPolizaRepository>();
            return services;
        }
    }
}
