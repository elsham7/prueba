﻿using bg.micros.core.polizas.application.interfaces.repositories;
using bg.micros.core.polizas.application.interfaces.services;
using bg.micros.core.polizas.application.models.exeptions;
using bg.micros.core.polizas.application.utils;
using bg.micros.core.polizas.domain.entities.simulacion;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Caching.Memory;

namespace bg.micros.core.polizas.application.services
{
    public class SimulacionRepository : ISimulacionRepository
    {
        private readonly ISimulacionRestRepository _simulacionRestRepository;
        private readonly IConfiguration _configuration;
        private readonly IMemoryCache _memoryCache;

        public SimulacionRepository(IConfiguration Configuration, ISimulacionRestRepository simulacionRestRepository,IMemoryCache Cache)
        {
            _simulacionRestRepository = simulacionRestRepository;
            _memoryCache = Cache;
            _configuration = Configuration;
        }

        public async Task<ConsultaSimulacionDTO> GeneraSimulacion(ConsultaSimulacionRequest request, bool consumirCore = false)
        {      
            ConsultaSimulacionDTO response = new ConsultaSimulacionDTO();
            ResponseTasaBipf? responseTasa = null;
            bool HabilitarCumulo = request.MontoAcumulado > 0;
            if (request.Monto <= 0 || request.Plazo <= 0 || String.IsNullOrEmpty(request.TipoPlazo))
            {
                throw new ContratoContactoException("Error de aplicativo", "Parametros invalidos para generar la simulacion.", 400);
            }
            if (!(request.TipoPlazo == "M" || request.TipoPlazo == "D")) {
                throw new ContratoContactoException("Error de aplicativo", "Parametros invalidos para generar la simulacion.", 400);
            }

            List<Simulacion>? SimulacionList = new List<Simulacion>();
            int dias = request.Plazo;
            if (request.TipoPlazo == "M")
            {
                int multiplicador = 30;
                if (request.Plazo == 1)
                {
                    multiplicador = 31;
                }
                dias = request.Plazo * multiplicador;
            }
            ConsultaSimulacionRequest requestTasa = new ConsultaSimulacionRequest();
            requestTasa.Monto = request.Monto;
            requestTasa.Plazo = dias;
            requestTasa.GenerarRecomendaciones= request.GenerarRecomendaciones;
            requestTasa.MontoAcumulado = !HabilitarCumulo ? 0M : request.MontoAcumulado;
            DateTimeUtils _utils = new DateTimeUtils();
            string fechaTasa = _utils.GetFirstDayOfWeek(DateTime.Today).ToString("yyyyMMdd");
            string ordsCacheKey = _configuration["BipfORDSCacheKey"] + fechaTasa;
            
            if (!consumirCore) {
                responseTasa = _memoryCache.Get<ResponseTasaBipf>(ordsCacheKey);
            }

            if (responseTasa == null)
            {
                responseTasa = await _simulacionRestRepository.ConsultaTasaBIPF(fechaTasa);
            }
            if (responseTasa== null)
            {
                throw new ContratoContactoException("Error de aplicativo", "Tabla Bipf vacia.", 400);
            }
            else
            {
                List<(int, decimal)> tasaList = new List<(int, decimal)>();
                tasaList= FiltrarTasaBipf(requestTasa, responseTasa);
                List<(int, decimal)> tasaListOriginal = new List<(int, decimal)>();
                
                if (HabilitarCumulo)
                {
                    requestTasa.MontoAcumulado = 0;
                    tasaListOriginal = FiltrarTasaBipf(requestTasa, responseTasa);
                }
                int contador = 1;
                for (int i = 0; i < tasaList.Count; i++)
                {
                    int itemPlazo = Convert.ToInt32(tasaList[i].Item1);      
                    decimal itemTasa = Convert.ToDecimal(tasaList[i].Item2); 
                    decimal interesGenerado = request.Monto * (itemTasa / 36000) * itemPlazo;
                    interesGenerado = Math.Floor(interesGenerado * 100) / 100;
                    decimal impuesto = 0;
                    decimal itemTasaOriginal = itemTasa;
                    if (itemPlazo < 180)
                    {
                        impuesto = Math.Round(interesGenerado * 2 / 100, 2);
                    }
                    int plazoResponse = itemPlazo;
                    if (request.TipoPlazo == "M")
                    {
                        int multiplicador = 30;
                        if (itemPlazo == 1)
                        {
                            multiplicador = 31;
                        }
                        plazoResponse = itemPlazo / multiplicador;
                    }
                    if (HabilitarCumulo && tasaListOriginal!= null && tasaListOriginal.Count>0)
                    {
                        tasaListOriginal = FiltrarTasaBipf(requestTasa, responseTasa);
                        int itemPlazoOriginal = Convert.ToInt32(tasaList[i].Item1);
                        if (itemPlazo == itemPlazoOriginal)
                        {
                            itemTasaOriginal = Convert.ToDecimal(tasaListOriginal[i].Item2);
                        }
                    }
                    var simulacionItem = new Simulacion
                    {
                        Indice = contador,
                        Monto = request.Monto,
                        Plazo = plazoResponse,
                        TipoDePlazo = request.TipoPlazo,
                        TasaDeInteres = itemTasa,
                        InteresGenerado = interesGenerado,
                        Impuesto = impuesto,
                        MontoFinal = request.Monto + interesGenerado - impuesto,
                        FechaVencimiento = DateTime.Today.AddDays(itemPlazo).ToString("yyyy/MM/dd"),
                        TasaInteresOriginal = itemTasaOriginal,
                        SimulacionCumulo= itemTasa > itemTasaOriginal
                    };
                    SimulacionList.Add(simulacionItem);
                    contador++;
                }               
                response.SimulacionList = SimulacionList;
            }
            return response;
        }

        public List<(int, decimal)> FiltrarTasaBipf(ConsultaSimulacionRequest request, ResponseTasaBipf responseTasa)
        {
            decimal montoFilter = request.Monto + request.MontoAcumulado;
            List<(int, decimal)> response = new List<(int, decimal)>();
            if (responseTasa != null && responseTasa.Data != null && responseTasa.Data.Count>0)
            {
                var firstItem = responseTasa.Data
                   .FirstOrDefault(item => item.Desde <= montoFilter && montoFilter <= item.Hasta);

                if (firstItem != null)
                {
                    response = ObtenerValorPorPlazo(firstItem, request.Plazo, request.GenerarRecomendaciones);
                } 
            }
            return response;
        }

        static List<(int, decimal)> ObtenerValorPorPlazo(TasaBipfItem item, int plazoEnDias, bool generarRecomendaciones)
        {
            decimal response = 0M;
            List<(int, decimal)> tasaList = new List<(int, decimal)>();
            var properties = typeof(TasaBipfItem).GetProperties()
                .Where(p => p.Name.StartsWith("To_"))
                .ToList();

            int contador = 0;
            bool matchMonto = false;
            foreach (var prop in properties)
            {
                var range = prop.Name.Replace("To_", "").Replace("_d", "").Split('_');
                int desde = int.Parse(range[0]);
                int hasta = int.Parse(range[1]);
                if (desde >= 31)
                {
                    if (plazoEnDias >= desde && plazoEnDias <= hasta)
                    {
                        matchMonto = true;
                        var tasaValue = prop.GetValue(item);
                        response = tasaValue != null ? decimal.Parse(tasaValue.ToString()) : 0m;
                        tasaList.Add((plazoEnDias, response));
                        continue;
                    }
                    if (matchMonto && generarRecomendaciones)
                    {
                        contador++;
                        if (contador%2 == 0)
                        {
                            var tasaValue = prop.GetValue(item);
                            response = tasaValue != null ? decimal.Parse(tasaValue.ToString()) : 0m;
                            tasaList.Add((desde, response));
                        }
                    }
                }
            }
            return tasaList;
        }
    }
}
