﻿using bg.micros.core.polizas.application.interfaces.repositories;
using bg.micros.core.polizas.application.interfaces.services;
using bg.micros.core.polizas.application.models.exeptions;
using bg.micros.core.polizas.application.utils;
using bg.micros.core.polizas.domain.entities.simulacion;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Caching.Memory;
using bg.micros.core.polizas.domain.entities.webServices;

using System.Data;

namespace bg.micros.core.polizas.application.services
{
    public class ExpedientePolizaRepository : IExpedientePolizaRepository
    {
        private readonly IExpedientePolizaRestRepository _expedientePolizaRestRepository;
        private readonly IConfiguration _configuration;

        public ExpedientePolizaRepository(IConfiguration Configuration, IExpedientePolizaRestRepository expedientePolizaRestRepository)
        {
            _expedientePolizaRestRepository = expedientePolizaRestRepository;
            _configuration = Configuration;
        }




        public Task<DataSet> consultarInformacionAdicionalPolizas(InformacionAdicionalPolizasRequest request)
        {
            DataSet responseDs = new DataSet();

   

            return Task.FromResult(responseDs);
        }

        public void LlenarElementosPoliza(ref List<CampoDto> listadoCampos, string nombreCampo, string valor, string tipo)
        {
            CampoDto tmpCmp = new CampoDto();
            tmpCmp.NombreDato = nombreCampo;
            tmpCmp.ValorDato = valor;
            tmpCmp.TipoDato = tipo;
            listadoCampos.Add(tmpCmp);
        }

        public void ControlError(GeneralCamposDto tmpParam, ref string error, ref string mensajeError)
        {

            mensajeError = "exitoso";
            error = "000";

            if (int.Parse(tmpParam.CodigoError == null ? "0" : tmpParam.CodigoError) != 0)
                error = tmpParam.CodigoError;
            mensajeError = tmpParam.MensajeError;

            if (tmpParam.ResultadoConsultas.Tables.Contains("ESTATUS") && tmpParam.ResultadoConsultas.Tables["ESTATUS"].Rows.Count > 0)
            {
                if (tmpParam.ResultadoConsultas.Tables["ESTATUS"].Rows[0]["CODIGO"].ToString() == "9")
                {
                    error = "999";
                    mensajeError = "Error";
                }
            }
        }
    }
}
