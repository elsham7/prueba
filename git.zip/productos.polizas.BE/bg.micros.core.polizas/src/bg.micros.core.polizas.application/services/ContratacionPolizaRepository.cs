﻿using bg.micros.core.polizas.application.interfaces.repositories;
using bg.micros.core.polizas.application.interfaces.services;
using bg.micros.core.polizas.application.models.exeptions;
using bg.micros.core.polizas.application.utils;
using bg.micros.core.polizas.domain.entities.simulacion;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Caching.Memory;
using bg.micros.core.polizas.domain.entities.webServices;
using bg.micros.core.polizas.infrastructure.data.repositories;

namespace bg.micros.core.polizas.application.services
{
    public class ContratacionPolizaRepository : IContratacionPolizaRepository
    {
        private readonly IContratacionPolizaRestRepository _contratacionPolizaRestRepository;
        private readonly IConfiguration _configuration;


        public ContratacionPolizaRepository(IConfiguration Configuration, IContratacionPolizaRestRepository contratacionPolizaRestRepository)
        {
            _contratacionPolizaRestRepository = contratacionPolizaRestRepository;

            _configuration = Configuration;
        }

        public async Task<PolizaContratacionDTO> ContratarPoliza(PolizaContratacionDTO request)
        {
            List<string> errores = request.ValidarCampos();

            if (errores != null && errores.Count > 0) {
                string erroresString= string.Join(", ", errores);
                throw new ContratoContactoException("Error de aplicativo", erroresString, 400);
            }

            PolizaContratacionDTO response = new PolizaContratacionDTO();
            response = await _contratacionPolizaRestRepository.ContratarPoliza(request);
            return response;

        }

        public async Task<ConsultaTasaInteresResponseDTO> ConsultaTasaInteres(ConsultaTasaInteresDTO request)
        {
            List<string> errores = request.ValidarCampos();

            if (errores != null && errores.Count > 0)
            {
                string erroresString = string.Join(", ", errores);
                throw new ContratoContactoException("Error de aplicativo", erroresString, 400);
            }
            ConsultaTasaInteresResponseDTO response = new ConsultaTasaInteresResponseDTO();
            response = await _contratacionPolizaRestRepository.ConsultaTasaInteres(request);
            return response;
        }
    }
}
