﻿using AutoMapper;
using bg.micros.core.polizas.application.interfaces.repositories;
using bg.micros.core.polizas.application.interfaces.services;
using bg.micros.core.polizas.domain.entities.datospolizas;
using bg.micros.core.polizas.domain.entities.polizas;
using Microsoft.Extensions.Configuration;


namespace bg.micros.core.polizas.application.services
{
    public class DetallePolizaRepository : IDetallePolizaRepository
    {
        private readonly IDetallePolizaRestRepository _detallePolizaRestRepository;
        private readonly IMapper _mapper;
        private readonly IConfiguration _configuration;

        public DetallePolizaRepository(IDetallePolizaRestRepository detallePolizaRestRepository, IMapper mapper, IConfiguration configuration)
        {
            _detallePolizaRestRepository = detallePolizaRestRepository;
            _mapper = mapper;
            _configuration = configuration;
        }
        public async Task<ResponseDetallePoliza> ObtenerDetallePoliza(RequestDetallePoliza request)
        {
            return await _detallePolizaRestRepository.ObtenerDetallePoliza(request);
        }

        public async Task<DatosPolizas> ObtenerDatosPoliza(DatosPolizasRequest request)
        {
            return await _detallePolizaRestRepository.ObtenerDatosPolizaRestRep(request);
        }
    }
}
