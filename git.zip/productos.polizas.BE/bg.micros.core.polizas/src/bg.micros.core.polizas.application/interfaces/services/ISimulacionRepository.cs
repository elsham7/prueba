﻿using bg.micros.core.polizas.domain.entities.simulacion;

namespace bg.micros.core.polizas.application.interfaces.services
{
    public interface ISimulacionRepository
    { 
        Task<ConsultaSimulacionDTO> GeneraSimulacion(ConsultaSimulacionRequest request, bool consumirCore = false);
        List<(int, decimal)> FiltrarTasaBipf(ConsultaSimulacionRequest request, ResponseTasaBipf responseTasa);
    }
}
