﻿using bg.micros.core.polizas.domain.entities.datospolizas;
using bg.micros.core.polizas.domain.entities.polizas;
namespace bg.micros.core.polizas.application.interfaces.services
{
    public interface IDetallePolizaRepository
    {
        Task<ResponseDetallePoliza> ObtenerDetallePoliza(RequestDetallePoliza request);

        Task<DatosPolizas> ObtenerDatosPoliza(DatosPolizasRequest request);
    }
}
