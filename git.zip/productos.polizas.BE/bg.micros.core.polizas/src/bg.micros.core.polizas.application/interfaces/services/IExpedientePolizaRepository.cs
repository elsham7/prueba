﻿using bg.micros.core.polizas.domain.entities.simulacion;
using bg.micros.core.polizas.domain.entities.webServices;
using System.Data;

namespace bg.micros.core.polizas.application.interfaces.services
{
    public interface IExpedientePolizaRepository
    {

        public Task<DataSet> consultarInformacionAdicionalPolizas(InformacionAdicionalPolizasRequest request);
        void LlenarElementosPoliza(ref List<CampoDto> listadoCampos, string nombreCampo, string valor, string tipo);
        void ControlError(GeneralCamposDto tmpParam, ref string error, ref string mensajeError);

    }
}
