﻿using bg.micros.core.polizas.domain.entities.webServices;

namespace bg.micros.core.polizas.infrastructure.data.repositories
{
    public interface IContratacionPolizaRestRepository
    {
        public Task<PolizaContratacionDTO> ContratarPoliza(PolizaContratacionDTO request);
        public Task<ConsultaTasaInteresResponseDTO> ConsultaTasaInteres(ConsultaTasaInteresDTO request);
    }
}