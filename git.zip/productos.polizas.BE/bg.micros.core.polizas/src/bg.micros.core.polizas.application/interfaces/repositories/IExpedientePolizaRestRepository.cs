﻿
using bg.micros.core.polizas.domain.entities.simulacion;
using bg.micros.core.polizas.domain.entities.webServices;
using System.Data;

namespace bg.micros.core.polizas.application.interfaces.repositories
{
    public interface IExpedientePolizaRestRepository
    {
        Task<DataSet> consultarInformacionAdicionalPolizas(GeneralCamposDto genCampos);
    }
}
