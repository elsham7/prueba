﻿using bg.micros.core.polizas.domain.entities.datospolizas;
using bg.micros.core.polizas.domain.entities.polizas;
namespace bg.micros.core.polizas.application.interfaces.repositories
{
    public interface IDetallePolizaRestRepository
    {
        Task<ResponseDetallePoliza> ObtenerDetallePoliza(RequestDetallePoliza request);

        Task<DatosPolizas> ObtenerDatosPolizaRestRep(DatosPolizasRequest request);
    }
}
