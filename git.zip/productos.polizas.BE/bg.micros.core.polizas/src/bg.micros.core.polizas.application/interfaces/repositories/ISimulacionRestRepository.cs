﻿
using bg.micros.core.polizas.domain.entities.simulacion;

namespace bg.micros.core.polizas.application.interfaces.repositories
{
    public interface ISimulacionRestRepository
    {
        Task<ResponseTasaBipf> ConsultaTasaBIPF(string fechaTasa);
    }
}
