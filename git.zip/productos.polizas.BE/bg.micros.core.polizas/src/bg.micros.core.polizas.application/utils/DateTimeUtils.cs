﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bg.micros.core.polizas.application.utils
{
    public class DateTimeUtils
    {
        public DateTime GetFirstDayOfWeek(DateTime date)
        {
            DayOfWeek dayOfWeek = date.DayOfWeek;
            int offset = dayOfWeek == DayOfWeek.Sunday ? -6 : DayOfWeek.Monday - dayOfWeek;
            DateTime firstDayOfWeek = date.AddDays(offset);

            return firstDayOfWeek;
        }

    }
}
