﻿namespace bg.micros.core.polizas.application.models.exeptions
{
    public class ContratoContactoException : BaseCustomException
    {
        public ContratoContactoException(string message = "Contrato Contacto Exception", string description = "", int statuscode = 500) : base(message, description, statuscode)
        {

        }
    }
}
