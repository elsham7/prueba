﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bg.micros.core.polizas.application.models.exeptions
{
    public class DatosPolizaException : BaseCustomException
    {
        public DatosPolizaException(string message = "DatosPoliza Exception", string stackTrace = "", int code = 500) : base(message, stackTrace, code)
        {
        }
    }
}
