﻿namespace bg.micros.core.polizas.application.models.exeptions
{
    public class PersonasException : BaseCustomException
    {
        public PersonasException(string message = "Personas Exception", string description = "", int statuscode = 500) : base(message, description, statuscode)
        {

        }
    }
}
