﻿using Microsoft.EntityFrameworkCore;
using AutoMapper;
using bg.productos.pasivos.aplicacion.modelos.pagination;

namespace bg.productos.pasivos.infraestructura.extentions
{
    public static class DataPagerExtensions
    {
        public static async Task<PaginationFilterResponse<T>> PaginateAsync<S, T>(
        this IQueryable<S> query,
        int startRow,
        int limit,
        IMapper _mapper,
        CancellationToken cancellationToken)
        {
            PaginationFilterResponse<T> paged = new PaginationFilterResponse<T>();
            paged.pagination.Limit = limit;
            List<S> consulta = await query.Skip(startRow).Take(limit).ToListAsync();
            paged.data = _mapper.Map<List<T>>(consulta);
            int totalItemsCountTask = await query.CountAsync();
            paged.pagination.Total = totalItemsCountTask;
            paged.pagination.Returned = consulta.Count();
            paged.pagination.Offset = startRow;
            return paged;
        }
        public static async Task<PaginationFilterResponse<T>> PaginateAsync<T>(
        this IQueryable<T> query,
        int startRow,
        int limit,
        CancellationToken cancellationToken)
        {
            PaginationFilterResponse<T> paged = new PaginationFilterResponse<T>();
            paged.pagination.Limit = limit;
            List<T> consulta = await query.Skip(startRow).Take(limit).ToListAsync();
            paged.data = consulta;
            int totalItemsCountTask = await query.CountAsync();
            paged.pagination.Total = totalItemsCountTask;
            paged.pagination.Returned = consulta.Count();
            paged.pagination.Offset = startRow;
            return paged;
        }


        public static PaginationFilterResponse<T> Paginate<T>(
            this IQueryable<T> query,
            int startRow,
            int limit,
            CancellationToken cancellationToken)
        {
            PaginationFilterResponse<T> paged = new PaginationFilterResponse<T>();
            paged.pagination.Limit = limit;
            List<T> consulta = query.Skip(startRow).Take(limit).ToList();
            paged.data = consulta;
            int totalItemsCountTask = query.Count();
            paged.pagination.Total = totalItemsCountTask;
            paged.pagination.Returned = consulta.Count();
            paged.pagination.Offset = startRow;
            return paged;
        }

    }
}
