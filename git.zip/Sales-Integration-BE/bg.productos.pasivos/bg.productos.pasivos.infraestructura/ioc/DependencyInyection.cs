﻿using bg.productos.pasivos.aplicacion.interfaces.repositorios;
using bg.productos.pasivos.aplicacion.interfaces.servicios;
using bg.productos.pasivos.infraestructura.data.repositorios;
using bg.productos.pasivos.infraestructura.data.servicios;
using bg.productos.pasivos.infraestructura.Observabilidad;
using bg.productos.pasivos.shared.extensiones;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System.Reflection;

namespace bg.productos.pasivos.infrastructure.ioc
{
    public static class DependencyInyection
    {
        public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
        {
            // Se agregan Logs ELK
            services.AddLoggingService(configuration);
            services.AddScoped<Logger, LoggerSerilog>();

            // Se agregan OpenTelemetry Otlp Exporter
            services.AddOpenTelemetryTracingService(configuration);
            // Se agregan HealthChecks
            services.AddHealthChecksService();
            
            services.AddHttpClient();

            services.AddAutoMapper(Assembly.GetExecutingAssembly());

            services.AddServiceFromAssembly(Assembly.GetExecutingAssembly());
            //services.AddScoped<ISolicitudPasivoJuridicaRepository, SolicitudPasivoJuridicaRepository>();

            return services;
        }
    }
}

