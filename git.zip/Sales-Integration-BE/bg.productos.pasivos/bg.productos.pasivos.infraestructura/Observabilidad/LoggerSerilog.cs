﻿using Serilog;

namespace bg.productos.pasivos.infraestructura.Observabilidad
{
    public class LoggerSerilog: Logger
    {
        public void Information(string messageTemplate, params object?[]? propertyValues)
        {
            Log.Information(messageTemplate, propertyValues);
        }

        public void Error(string messageTemplate, params object?[]? propertyValues)
        {
            Log.Error(messageTemplate, propertyValues);
        }
        public void Warning(string messageTemplate, params object?[]? propertyValues)
        {
            Log.Warning(messageTemplate, propertyValues);
        }
        public void Fatal(string messageTemplate, params object?[]? propertyValues)
        {
            Log.Fatal(messageTemplate, propertyValues);
        }
    }
}
