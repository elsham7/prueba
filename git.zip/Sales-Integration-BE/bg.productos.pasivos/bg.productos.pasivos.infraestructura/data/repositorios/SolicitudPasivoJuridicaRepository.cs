﻿using AutoMapper;
using bg.productos.pasivos.aplicacion.interfaces.repositorios;
using bg.productos.pasivos.aplicacion.interfaces.servicios;
using bg.productos.pasivos.aplicacion.modelos.dtos.responses;
using bg.productos.pasivos.dominio.entidades.solicitudes.solicitudPasivoJuridica;
using Microsoft.Extensions.Configuration;

namespace bg.productos.pasivos.infraestructura.data.repositorios
{
    public class SolicitudPasivoJuridicaRepository : ISolicitudPasivoJuridicaRepository, IServicesScoped
    {
        private readonly IConfiguration _configuration;
        private readonly IMapper _mapper;
        private readonly IHttpRequestService _httpRequestService;

        public SolicitudPasivoJuridicaRepository(IConfiguration configuration, IHttpRequestService httpRequestService, IMapper mapper)
        {
            _configuration=configuration;
            _httpRequestService=httpRequestService;
            _mapper=mapper;
        }

        public async Task<SolicitudPasivoJuridicaResponse> EnviarSocilitudPasivoJuridica(SolicitudPasivoJuridicaRequest request)
        {
            var uri = string.Format(_configuration["InfraConfig:Micros:Cuentas:urlService"]!) + "cuentas/v1/solicitud/pasivo-juridica";
            var response = await _httpRequestService
                .ExecuteRestRequestAsync<MsDtoResponseSuccess<SolicitudPasivoJuridicaResponse>, SolicitudPasivoJuridicaResponse>
                (uri, 
                HttpMethod.Post, 
                null, 
                null,
                request, 
                mapFunction: source => _mapper.Map<SolicitudPasivoJuridicaResponse>(source.Data));
            
            return response;
        }
    }
}
