﻿using Microsoft.Extensions.DependencyInjection;
using System.Reflection;

namespace bg.productos.pasivos.shared.extensiones
{
    public static class DependencyInjectionExtensions
    {
        public static IServiceCollection AddServiceFromAssembly(this IServiceCollection services, Assembly assembly)
        {
            services.Scan(scan => scan
                  .FromAssemblies(assembly)
                  .AddClasses(classes => classes.AssignableTo<IServicesScoped>())
                      .AsImplementedInterfaces(i => i != typeof(IServicesScoped))
                      .WithScopedLifetime()
                  .AddClasses(classes => classes.AssignableTo<IServicesSingleton>())
                      .AsImplementedInterfaces(i => i != typeof(IServicesSingleton))
                      .WithSingletonLifetime()
                  .AddClasses(classes => classes.AssignableTo<IServicesTransient>())
                      .AsImplementedInterfaces(i => i != typeof(IServicesTransient))
                      .WithTransientLifetime()
          );

            return services;
        }
    }
}
