﻿
    public interface IServicesScoped
    {
    }
