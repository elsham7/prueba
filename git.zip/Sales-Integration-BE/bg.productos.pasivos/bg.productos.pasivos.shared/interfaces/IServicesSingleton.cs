﻿
    public interface IServicesSingleton
    {
    }

