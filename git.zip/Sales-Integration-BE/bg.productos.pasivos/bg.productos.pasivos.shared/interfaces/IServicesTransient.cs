﻿    public interface IServicesTransient
    {
    }

