﻿using bg.productos.pasivos.dominio.constants;
using bg.productos.pasivos.dominio.entidades.solicitudes.solicitudPasivoJuridica;
using FluentValidation;

namespace bg.productos.pasivos.aplicacion.objectValidation
{
    public class SolicitudPasivoJuridicaValidator : AbstractValidator<SolicitudPasivoJuridicaRequest>
    {
        public SolicitudPasivoJuridicaValidator()
        {
            RuleFor(x => x.Verificacion)
             .NotEmpty().WithMessage(Verificacion => string.Format(GlobalConst.MSG_CAMPO_REQUERIDO, nameof(Verificacion)));

            RuleFor(x => x.Verificacion)
                .Custom(y => y.)
             
        }
    }
}
