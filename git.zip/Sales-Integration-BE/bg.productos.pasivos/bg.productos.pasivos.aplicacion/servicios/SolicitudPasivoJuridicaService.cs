﻿using bg.productos.pasivos.aplicacion.interfaces.repositorios;
using bg.productos.pasivos.aplicacion.interfaces.servicios;
using bg.productos.pasivos.aplicacion.modelos.excepciones;
using bg.productos.pasivos.dominio.entidades.solicitudes.solicitudPasivoJuridica;
using FluentValidation;

namespace bg.productos.pasivos.aplicacion.servicios
{
    public class SolicitudPasivoJuridicaService : ISolicitudPasivoJuridicaService, IServicesScoped
    {
        private readonly ISolicitudPasivoJuridicaRepository _solicitudPasivoJuridicaRepository;
        private readonly IValidator<SolicitudPasivoJuridicaRequest> _validatorSolicitudPasivoJuridica;

        public SolicitudPasivoJuridicaService(ISolicitudPasivoJuridicaRepository solicitudPasivoJuridicaRepository, IValidator<SolicitudPasivoJuridicaRequest> validatorSolicitudPasivoJuridica)
        {
            _solicitudPasivoJuridicaRepository=solicitudPasivoJuridicaRepository;
            _validatorSolicitudPasivoJuridica=validatorSolicitudPasivoJuridica;
        }

        public async Task<SolicitudPasivoJuridicaResponse> EnviarSocilitudPasivoJuridica(SolicitudPasivoJuridicaRequest request)
        {
            var isValidRequest = _validatorSolicitudPasivoJuridica.Validate(request);
            if (!isValidRequest.IsValid)
                throw new BadRequestException(string.Empty, isValidRequest.Errors.Select(x => x.ErrorMessage).ToList());

            var response = await _solicitudPasivoJuridicaRepository.EnviarSocilitudPasivoJuridica(request);
            if (response == null)
                throw new NotFoundException("Error aplicativo");
            return response;
        }
    }
}
