﻿using bg.productos.pasivos.aplicacion.interfaces.repositorios;
using bg.productos.pasivos.aplicacion.interfaces.servicios;
using bg.productos.pasivos.aplicacion.modelos.excepciones;
using bg.productos.pasivos.dominio.entidades.solicitudes.ConsultaTasaPolizas;
using FluentValidation;

namespace bg.productos.pasivos.aplicacion.servicios
{
    public class ConsultaTasaPolizasService : IConsultaTasaPolizasService, IServicesScoped
    {
        private readonly IConsultaTasaPolizasRepository _consultaTasaPolizasRepository;
        private readonly IValidator<ConsultaTasaPolizasRequest> _validatorConsultaTasaPolizas;

        public SolicitudPasivoJuridicaService(IConsultaTasaPolizasRepository consultaTasaPolizasRepository, IValidator<ConsultaTasaPolizasRequest> validatorConsultaTasaPolizas)
        {
            _consultaTasaPolizasRepository = consultaTasaPolizasRepository;
            _validatorConsultaTasaPolizas = validatorConsultaTasaPolizas;
        }

        public async Task<ConsultaTasaPolizasResponse> EnviarTasaPolizas(ConsultaTasaPolizasRequest request)
        {
            var isValidRequest = _validatorConsultaTasaPolizas.Validate(request);
            if (!isValidRequest.IsValid)
                throw new BadRequestException(string.Empty, isValidRequest.Errors.Select(x => x.ErrorMessage).ToList());

            var response = await _consultaTasaPolizasRepository.EnviarTasaPolizas(request);
            if (response == null)
                throw new NotFoundException("Error aplicativo");
            return response;
        }
    }
}
