﻿using bg.productos.pasivos.aplicacion.interfaces.servicios;
using bg.productos.pasivos.aplicacion.servicios;
using bg.productos.pasivos.shared.extensiones;
using FluentValidation;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System.Reflection;

namespace bg.productos.pasivos.aplicacion.ioc
{
    public static class DependencyInyection
    {
        public static IServiceCollection AddApplication(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddValidatorsFromAssembly(Assembly.GetExecutingAssembly());

            services.AddServiceFromAssembly(Assembly.GetExecutingAssembly());
            services.AddScoped<ISolicitudPasivoJuridicaService, SolicitudPasivoJuridicaService>();
            services.AddScoped<IConsultaTasaPolizasService, ConsultaTasaPolizasService>();

            return services;
        }
    }
}
