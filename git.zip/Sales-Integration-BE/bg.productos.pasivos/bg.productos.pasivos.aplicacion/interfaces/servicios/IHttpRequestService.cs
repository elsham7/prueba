﻿using Newtonsoft.Json;
using System.Runtime.CompilerServices;

namespace bg.productos.pasivos.aplicacion.interfaces.servicios
{
    public interface IHttpRequestService
    {
        /// <summary>
        /// Realiza una solicitud HTTP genérica (GET, POST, PUT, DELETE), deserializa la respuesta y mapea los datos a un tipo destino.
        /// 
        /// La función admite la adición de encabezados personalizados, parámetros de consulta (query params),
        /// contenido en el cuerpo para solicitudes POST o PUT, y permite configurar el tiempo de espera.
        /// Además, permite mapear la respuesta deserializada de un tipo fuente (TSource) a un tipo destino (TDestination) mediante una función de mapeo.
        /// </summary>
        /// <typeparam name="TSource">El tipo de la clase que representa la respuesta original deserializada.</typeparam>
        /// <typeparam name="TDestination">El tipo de la clase destino al que se desea mapear la respuesta.</typeparam>
        /// <param name="url">La URL del servicio REST.</param>
        /// <param name="method">El método HTTP a utilizar (GET, POST, PUT, DELETE).</param>
        /// <param name="headers">Diccionario de encabezados personalizados para agregar a la solicitud.</param>
        /// <param name="queryParams">Diccionario de parámetros de consulta (query params) para agregar a la URL.</param>
        /// <param name="content">Contenido del cuerpo de la solicitud (solo para POST o PUT), para serealizazr en JSON.</param>
        /// <param name="timeoutMilliseconds">El tiempo máximo de espera para la solicitud en milisegundos.</param>
        /// <param name="jsonSettings">Configuracion para la deserealizacion (TSource) </param>
        /// <param name="mapFunction">Función opcional para mapear la respuesta de TSource a TDestination.</param>
        /// <returns>Devuelve una instancia de TDestination que contiene los datos mapeados de la respuesta.</returns>
        /// <exception cref="ArgumentException">Lanzada si la URL es nula o vacía.</exception>
        /// <exception cref="ArgumentNullException">Lanzada si el método HTTP o el contenido (en POST o PUT) es nulo.</exception>
        /// <exception cref="ArgumentOutOfRangeException">Lanzada si el tiempo de espera es menor o igual a cero.</exception>
        /// <exception cref="InvalidOperationException">Lanzada si los tipos TSource y TDestination son diferentes y no se proporciona una función de mapeo.</exception>
        /// <exception cref="TimeoutException">Lanzada si la solicitud excede el tiempo de espera.</exception>
        /// <exception cref="HttpRequestException">Lanzada si hay un error en la solicitud HTTP.</exception>
        /// <exception cref="Exception">Lanzada si ocurre un error durante el proceso de la solicitud.</exception>
        Task<TDestination> ExecuteRestRequestAsync<TSource, TDestination>(string url, HttpMethod method, Dictionary<string, string>? headers = null, Dictionary<string, string>? queryParams = null, object? content = null, bool isFormEncoded = false, int timeoutMilliseconds = 15000, Func<TSource, TDestination>? mapFunction = null, JsonSerializerSettings? jsonSettings = null, [CallerMemberName] string? callerName = null);
    }
}
