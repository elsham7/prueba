﻿using bg.productos.pasivos.dominio.entidades.solicitudes.solicitudPasivoJuridica;

namespace bg.productos.pasivos.aplicacion.interfaces.servicios
{
    public interface ISolicitudPasivoJuridicaService
    {
        Task<SolicitudPasivoJuridicaResponse> EnviarSocilitudPasivoJuridica(SolicitudPasivoJuridicaRequest request);
    }
}
