﻿using bg.productos.pasivos.dominio.entidades.solicitudes.solicitudPasivoJuridica;

namespace bg.productos.pasivos.aplicacion.interfaces.repositorios
{
    public interface ISolicitudPasivoJuridicaRepository
    {
        Task<SolicitudPasivoJuridicaResponse> EnviarSocilitudPasivoJuridica(SolicitudPasivoJuridicaRequest request);
    }
}
