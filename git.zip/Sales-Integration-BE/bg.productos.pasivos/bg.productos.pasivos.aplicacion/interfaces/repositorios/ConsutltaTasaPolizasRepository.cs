﻿using bg.productos.pasivos.dominio.entidades.solicitudes.consultaTasaPolizas;

namespace bg.productos.pasivos.aplicacion.interfaces.repositorios
{
    public interface IConsultaTasaPolizasRepository
    {
        Task<ConsultaTasaPolizasResponse> EnviarTasaPolizas(ConsultaTasaPolizasRequest request);
    }
}
