﻿namespace bg.productos.pasivos.aplicacion.Utils
{
    public static class ValidarFormatoBase64
    {
        public static bool EsStringBase64(this string stringBase64)
        {
            try
            {
                Convert.FromBase64String(stringBase64);
                return true;
            }
            catch (FormatException ex)
            {
                return false;
            }
        }
    }
}
