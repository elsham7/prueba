﻿using System.Globalization; 
using System.Text;
using System.Text.RegularExpressions; 

namespace bg.productos.pasivos.aplicacion.Utils
{
    public static class ObfuscatorUtils
    {
        public static string? IdentificationNullableObfuscator(this string? identification)
        {
            if (identification == null)
            {
                return null;
            }
            return Regex.Replace(identification, @"(?<!^.?).(?!.?$)", "X");
        }
        public static string IdentificationObfuscator(this string identification)
        {
            return Regex.Replace(identification, @"(?<!^.?).(?!.?$)", "X");
        }

        public static string RemoverTildesYCaracteresNoAfabeticos(this string nombre)
        {
            string normalizeString = nombre.Normalize(NormalizationForm.FormD);
            StringBuilder sb = new();
            foreach (char c in normalizeString)
            {
                if (CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark)
                {
                    sb.Append(c);
                }
            }

            return sb.ToString();
        }
    }
}
