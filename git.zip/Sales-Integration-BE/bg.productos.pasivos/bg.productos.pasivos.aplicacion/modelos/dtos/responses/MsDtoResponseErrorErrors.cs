namespace bg.productos.pasivos.aplicacion.modelos.dtos.responses
{
    public partial class MsDtoResponseErrorErrors
    {
        public int Code { get; set; }
        public string? Message { get; set; }
    }
}
