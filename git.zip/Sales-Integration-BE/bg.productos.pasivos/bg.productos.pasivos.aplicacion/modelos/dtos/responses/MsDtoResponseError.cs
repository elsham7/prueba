﻿using bg.productos.pasivos.aplicacion.modelos.dtos.responses;

namespace bg.productos.pasivos.aplicacion.entidades.dtos.responses
{
    public class MsDtoResponseError
    {
        public int Code { get; set; }
        public string? Traceid { get; set; }
        public string? Message { get; set; }
        public List<MsDtoResponseErrorErrors>? Errors { get; set; }
    }
}
