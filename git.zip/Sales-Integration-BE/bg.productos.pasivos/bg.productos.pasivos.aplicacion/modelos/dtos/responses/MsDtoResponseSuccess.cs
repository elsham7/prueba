﻿using System.Net;
using System.Runtime.Serialization;

namespace bg.productos.pasivos.aplicacion.modelos.dtos.responses
{
    public class MsDtoResponseSuccess<T>
    {
        /// <summary>
        /// Traceid
        /// </summary>
        [DataMember(Name = "traceid")]
        public string? Traceid { get; set; }
        /// <summary>
        /// Data
        /// </summary>
        [DataMember(Name = "data")]
        public T Data { get; set; }

        /// <summary>
        /// MsDtoResponseSuccess
        /// </summary>
        /// <param name="code"></param>
        /// <param name="traceid"></param>
        /// <param name="data"></param>
        public MsDtoResponseSuccess(string traceid, T data)
        {
            Traceid = traceid;
            Data = data;
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class MsDtoResponseSuccessV2<T>
    {
        /// <summary>
        /// 
        /// </summary>
        [DataMember(Name = "code")]
        public int Code { get; set; }
        /// <summary>
        /// Traceid
        /// </summary>
        [DataMember(Name = "traceid")]
        public string? Traceid { get; set; }
        /// <summary>
        /// Data
        /// </summary>
        [DataMember(Name = "data")]
        public T Data { get; set; }

        /// <summary>
        /// MsDtoResponseSuccess
        /// </summary>
        /// <param name="code"></param>
        /// <param name="traceid"></param>
        /// <param name="data"></param>
        public MsDtoResponseSuccessV2(string traceid, T data)
        {
            Code = (int)HttpStatusCode.OK;
            Traceid = traceid;
            Data = data;
        }
    }
}
