﻿namespace bg.productos.pasivos.aplicacion.models.ms
{
    public class MsError
    {
        public int? status { set; get; }
        public string? errorCode { set; get; }
        public string? userMessage { set; get; }
        public string? traceId { set; get; }
    }
}
