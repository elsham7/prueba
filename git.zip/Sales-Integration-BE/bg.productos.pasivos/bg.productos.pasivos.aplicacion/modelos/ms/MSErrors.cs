﻿using bg.productos.pasivos.aplicacion.modelos.excepciones;

namespace bg.productos.pasivos.aplicacion.models.ms
{
    public class MSErrors
    {
        public static BaseCustomException AGENCIA_NO_EXISTE = new BaseCustomException("9002", "No se pudo realizar la consulta", 500);
    }
}
