﻿namespace bg.productos.pasivos.aplicacion.modelos.excepciones
{
    public class BadRequestException : Exception
    {
        public List<string> Errors { get; private set; }

        public BadRequestException(string message, List<string>? errors = null) : base(message)
        {
            Errors = errors!;
        }
    }
}
