﻿namespace bg.productos.pasivos.aplicacion.modelos.pagination
{
    public class PaginationFilterRequest<T>
    {
        public int skip { set; get; }
        public int take { set; get; }
        public DateTime? startDate { set; get; }
        public DateTime? endDate { set; get; }
        public T filter { set; get; }
    }
    public class PaginationFilterRequest
    {
        public int skip { set; get; }
        public int take { set; get; }
        public DateTime? startDate { set; get; }
        public DateTime? endDate { set; get; }
    }
}
