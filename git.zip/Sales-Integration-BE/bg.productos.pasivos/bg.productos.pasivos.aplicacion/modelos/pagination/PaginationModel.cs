﻿namespace bg.productos.pasivos.aplicacion.modelos.pagination
{
    public class PaginationModel
    {
        public int Limit { set; get; }
        public int Offset { set; get; }
        public int Returned { set; get; }
        public int Total { set; get; }
    }
}
