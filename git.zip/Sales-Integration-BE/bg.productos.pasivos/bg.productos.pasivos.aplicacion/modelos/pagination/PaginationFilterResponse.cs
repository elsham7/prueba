﻿namespace bg.productos.pasivos.aplicacion.modelos.pagination
{
    public class PaginationFilterResponse<T>
    {
        public PaginationFilterResponse()
        {
            data = new List<T>();
            pagination = new PaginationModel();
        }
        public IList<T> data { set; get; }
        public PaginationModel pagination { set; get; }
    }
}
