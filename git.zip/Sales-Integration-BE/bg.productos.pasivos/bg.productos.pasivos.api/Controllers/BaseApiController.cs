using Microsoft.AspNetCore.Mvc;

namespace bg.productos.pasivos.api.Controllers
{
    [ApiController]
    public abstract class BaseApiController : ControllerBase
    {
    }
}
