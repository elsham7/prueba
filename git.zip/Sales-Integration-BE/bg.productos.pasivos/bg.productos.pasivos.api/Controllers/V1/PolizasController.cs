using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;
using bg.productos.pasivos.dominio.entidades.solicitudes.solicitudPasivoJuridica;
using bg.productos.pasivos.aplicacion.modelos.dtos.responses;
using bg.productos.pasivos.aplicacion.interfaces.servicios;
using bg.productos.pasivos.aplicacion.entidades.dtos.responses;

namespace bg.productos.pasivos.api.Controllers.V1
{
    [ApiExplorerSettings(GroupName = "v1")]
    [ControllerName("Pasivos")]
    [ApiController]
    [Route("pasivos/api/v1")]
    public class PolizasController : BaseApiController
    {
        private readonly IConsultaTasaPolizasService _consultaTasaPolizasService;
        public VentasController(IConsultaTasaPolizasService consultaTasaPolizasService)
        {
            _consultaTasaPolizasService = consultaTasaPolizasService;
        }

        /// <summary>
        /// Consulta de Tasas (Polizas)
        /// </summary>
        /// <param name="request" example='{"VERIFICACION":{"PROGRAMA":"","LOGIN":"","PLATAFORMA":"","CODTRANSID":"","RETORNO":"","MENSAJE":"","OPID":"","TERMINAL":"","FECHA_TRANSACCION":"25022025","HORA_TRANSACCION":"103511","FILLER":["","",""],"ACCION":"1","SOLICITUD_CRONOS":"21025727","TIPO_CUENTA":"CC","CODIGO_CLIENTE":"2755909","RESPONSABLE":"LBA","TIPO_IDENT":"C","CODIGO_IDENT":"0922604681","FECHA_PASAPORTE":"","NOMBRE":"CARRASCO IDROVO VERONICA JANNETH","NACIONALIDAD":"ECS","FECHA_NACIMIENTO":"12/01/1984","SEXO":"F","ESTADO_CIVIL":"D","DIR_DOMICILIO":"AV PRINCIPALSADFASDF","CIUDAD_DOMICILIO":"ABM","TLF_DOMICILIO_1":"042334679","TLF_DOMICILIO_2":"","DIR_TRABAJO":"PEDRO CARBO Y COLON","CIUDAD_TRABAJO":"GYE","TLF_TRABAJO_1":"0984789654","TLF_TRABAJO_2":"","EMAIL":"noregistra@neo.com","PROFESION":"04","CODIGO_ACTIVIDAD":"037","ACTIVIDAD_R184":"037","PERSONA_R184":"","ACTIVIDAD":"Tabla Actividades Economicas","CODIGO_CORREO":"","CODIGO_CASILLA":"","CORRESPONDENCIA":"D","TIPO_CHEQUERA":"C","CLASE_CUENTA":"","TIPO_BANCA":"P","DOCUMENTOS_PEND":"","ORIGEN_CLIENTE":"XX","VENTAS_ANUALES":"0","NOMBRE_CHEQ_LIBRETA":"CARRASCO IDROVO VERONICA JANNETH","TARJETA_DEBITO":"S","NOMBRE_TARJETA":"VERONICA CARRASCO","DEPOSITO_INICIAL":"0.00","DEPOSITO_CHEQUE_PROV":"","NUMERO_TRANSACCION":"","VALOR_TRANSACCION":"","CODIGO_TRATO":"","FECHA_VENCIMIENTO":"","VALOR_SOBREGIRO":"","VALOR_PATRIMONIO":"","FECHA_PATRIMONIO":"","FONDO_RESPALDO_CNB":"","TIPO_MONEDA":"USD","CODIGO_POLITICAS_OFAC":"","DESCRIPCION_POL_OFAC":"","VERIFICA_DIRECCION":"S","NUM_PLANILLA":"","EMPRESA":"","FECHA_PLANILLA":"","REPRESENTANTES":[{"NOMBREREP":"GOMEZ JIMENEZ REGINA DEL ROSARIO","RELACIONREP":"TIT","TIPOIDREP":"C","CODIGOIDREP":"0915700645","TIPOBANCAREP":"A","SEXOREP":"F","FECHANACIMIENTOREP":"19740717","NACIONALIDADREP":"ECS"},{"NOMBREREP":"MU�OZ LOOR CRISTHIAN ANTONIO","RELACIONREP":"F/A","TIPOIDREP":"C","CODIGOIDREP":"2400128035","TIPOBANCAREP":"P","SEXOREP":"M","FECHANACIMIENTOREP":"19940821","NACIONALIDADREP":"ECS"}],"USUARIO_ADICION":"jyanez","IDENTIFICACION_ALTERNO":"","NOMBRE_CUENTA":"","AGENCIA_CLIENTE":"01","EMAIL_NEW":"","ACTIVIDAD_REG_NEW":"","ASIGNAR_CTA_ADIC":""}}'></param>
        /// <returns></returns>
        [HttpPost]
        [Route("solicitudes/cuentas")]
        [ProducesResponseType(typeof(MsDtoResponseSuccess<ConsultaTasaPolizasResponse>), 200)]
        [ProducesResponseType(typeof(MsDtoResponseError), 400)]
        [ProducesResponseType(typeof(MsDtoResponseError), 500)]
        public async Task<IActionResult> ConsultaTasaPolizas([FromBody][Required] ConsultaTasaPolizasRequest request)
        {
            var response = await _consultaTasaPolizasService.EnviarTasaPolizas(request);
            return Ok(new MsDtoResponseSuccess<ConsultaTasaPolizasResponse>(HttpContext?.TraceIdentifier!, response));
        }
    }
}
