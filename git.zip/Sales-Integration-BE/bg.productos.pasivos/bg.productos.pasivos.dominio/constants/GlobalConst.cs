﻿namespace bg.productos.pasivos.dominio.constants
{
    public static class GlobalConst
    {
        public const string MSG_CAMPO_REQUERIDO = "¡Lo sentimos!. El campo {0} es  requerido";
    }
}
