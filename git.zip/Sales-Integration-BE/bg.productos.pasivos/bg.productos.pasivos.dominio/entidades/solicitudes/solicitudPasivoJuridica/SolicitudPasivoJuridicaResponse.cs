﻿using Newtonsoft.Json;

namespace bg.productos.pasivos.dominio.entidades.solicitudes.solicitudPasivoJuridica
{
    public class SolicitudPasivoJuridicaResponse
    {
        /// <summary>
        /// Mensaje de respuesta del servidor.
        /// </summary>
        [JsonProperty("MENSAJE")]
        public string? Mensaje { get; set; }

        /// <summary>
        /// Código de solicitud del host.
        /// </summary>
        [JsonProperty("COD_SOLICITUD_HOST")]
        public string? Cod_Solicitud_Host { get; set; }

        /// <summary>
        /// Número de cuenta.
        /// </summary>
        [JsonProperty("NUM_CUENTA")]
        public string? Num_Cuenta { get; set; }

        /// <summary>
        /// Estatus de la solicitud.
        /// </summary>
        [JsonProperty("ESTATUS_SOLICITUD")]
        public string? Estatus_Solicitud { get; set; }

        /// <summary>
        /// Plaza asociada.
        /// </summary>
        [JsonProperty("PLAZA")]
        public string? Plaza { get; set; }

        /// <summary>
        /// Agencia asociada.
        /// </summary>
        [JsonProperty("AGENCIA")]
        public string? Agencia { get; set; }

        /// <summary>
        /// Marca de la libreta.
        /// </summary>
        [JsonProperty("MARCA_LIBRETA")]
        public string? Marca_Libreta { get; set; }

        /// <summary>
        /// Estado de la cuenta.
        /// </summary>
        [JsonProperty("ESTADO_CUENTA")]
        public string? Estado_Cuenta { get; set; }
    }
}
