﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace bg.productos.pasivos.dominio.entidades.solicitudes.solicitudPasivoJuridica
{
    public class SolicitudPasivoJuridicaRequest
    {
        [JsonProperty("VERIFICACION")]
        public Verificacion? Verificacion { get; set; }
    }

    public class Verificacion
    {
        /// <summary>
        /// Código del programa.
        /// </summary>
        [JsonProperty("PROGRAMA")]
        public string? Programa { get; set; }

        /// <summary>
        /// Login del usuario.
        /// </summary>
        [JsonProperty("LOGIN")]
        public string? Login { get; set; }

        /// <summary>
        /// Plataforma utilizada.
        /// </summary>
        [JsonProperty("PLATAFORMA")]
        public string? Plataforma { get; set; }

        /// <summary>
        /// Código de transacción.
        /// </summary>
        [JsonProperty("CODTRANSID")]
        public string? CodTransId { get; set; }

        /// <summary>
        /// Código de retorno.
        /// </summary>
        [JsonProperty("RETORNO")]
        public string? Retorno { get; set; }

        /// <summary>
        /// Mensaje de la transacción.
        /// </summary>
        [JsonProperty("MENSAJE")]
        public string? Mensaje { get; set; }

        /// <summary>
        /// Identificador de operación.
        /// </summary>
        [JsonProperty("OPID")]
        public string? OpId { get; set; }

        /// <summary>
        /// Terminal utilizada.
        /// </summary>
        [JsonProperty("TERMINAL")]
        public string? Terminal { get; set; }

        /// <summary>
        /// Fecha de la transacción.
        /// </summary>
        [JsonProperty("FECHA_TRANSACCION")]
        public string? Fecha_Transaccion { get; set; }

        /// <summary>
        /// Hora de la transacción.
        /// </summary>
        [JsonProperty("HORA_TRANSACCION")]
        public string? Hora_Transaccion { get; set; }

        /// <summary>
        /// Lista de relleno.
        /// </summary>
        [JsonProperty("FILLER")]
        public List<string>? Filler { get; set; }

        /// <summary>
        /// Acción realizada.
        /// </summary>
        [JsonProperty("ACCION")]
        public string? Accion { get; set; }

        /// <summary>
        /// Solicitud de Cronos.
        /// </summary>
        [JsonProperty("SOLICITUD_CRONOS")]
        public string? Solicitud_Cronos { get; set; }

        /// <summary>
        /// Tipo de cuenta.
        /// </summary>
        [JsonProperty("TIPO_CUENTA")]
        public string? Tipo_Cuenta { get; set; }

        /// <summary>
        /// Código del cliente.
        /// </summary>
        [JsonProperty("CODIGO_CLIENTE")]
        public string? Codigo_Cliente { get; set; }

        /// <summary>
        /// Responsable de la transacción.
        /// </summary>
        [JsonProperty("RESPONSABLE")]
        public string? Responsable { get; set; }

        /// <summary>
        /// Tipo de identificación.
        /// </summary>
        [JsonProperty("TIPO_IDENT")]
        public string? Tipo_Ident { get; set; }

        /// <summary>
        /// Código de identificación.
        /// </summary>
        [JsonProperty("CODIGO_IDENT")]
        public string? Codigo_Ident { get; set; }

        /// <summary>
        /// Fecha de pasaporte.
        /// </summary>
        [JsonProperty("FECHA_PASAPORTE")]
        public string? Fecha_Pasaporte { get; set; }

        /// <summary>
        /// Nombre del cliente.
        /// </summary>
        [JsonProperty("NOMBRE")]
        public string? Nombre { get; set; }

        /// <summary>
        /// Nacionalidad del cliente.
        /// </summary>
        [JsonProperty("NACIONALIDAD")]
        public string? Nacionalidad { get; set; }

        /// <summary>
        /// Fecha de nacimiento del cliente.
        /// </summary>
        [JsonProperty("FECHA_NACIMIENTO")]
        public string? Fecha_Nacimiento { get; set; }

        /// <summary>
        /// Sexo del cliente.
        /// </summary>
        [JsonProperty("SEXO")]
        public string? Sexo { get; set; }

        /// <summary>
        /// Estado civil del cliente.
        /// </summary>
        [JsonProperty("ESTADO_CIVIL")]
        public string? Estado_Civil { get; set; }

        /// <summary>
        /// Dirección de domicilio del cliente.
        /// </summary>
        [JsonProperty("DIR_DOMICILIO")]
        public string? Dir_Domicilio { get; set; }

        /// <summary>
        /// Ciudad de domicilio del cliente.
        /// </summary>
        [JsonProperty("CIUDAD_DOMICILIO")]
        public string? Ciudad_Domicilio { get; set; }

        /// <summary>
        /// Teléfono de domicilio 1 del cliente.
        /// </summary>
        [JsonProperty("TLF_DOMICILIO_1")]
        public string? Tlf_Domicilio_1 { get; set; }

        /// <summary>
        /// Teléfono de domicilio 2 del cliente.
        /// </summary>
        [JsonProperty("TLF_DOMICILIO_2")]
        public string? Tlf_Domicilio_2 { get; set; }

        /// <summary>
        /// Dirección de trabajo del cliente.
        /// </summary>
        [JsonProperty("DIR_TRABAJO")]
        public string? Dir_Trabajo { get; set; }

        /// <summary>
        /// Ciudad de trabajo del cliente.
        /// </summary>
        [JsonProperty("CIUDAD_TRABAJO")]
        public string? Ciudad_Trabajo { get; set; }

        /// <summary>
        /// Teléfono de trabajo 1 del cliente.
        /// </summary>
        [JsonProperty("TLF_TRABAJO_1")]
        public string? Tlf_Trabajo_1 { get; set; }

        /// <summary>
        /// Teléfono de trabajo 2 del cliente.
        /// </summary>
        [JsonProperty("TLF_TRABAJO_2")]
        public string? Tlf_Trabajo_2 { get; set; }

        /// <summary>
        /// Email del cliente.
        /// </summary>
        [JsonProperty("EMAIL")]
        public string? Email { get; set; }

        /// <summary>
        /// Profesión del cliente.
        /// </summary>
        [JsonProperty("PROFESION")]
        public string? Profesion { get; set; }

        /// <summary>
        /// Código de actividad económica.
        /// </summary>
        [JsonProperty("CODIGO_ACTIVIDAD")]
        public string? Codigo_Actividad { get; set; }

        /// <summary>
        /// Actividad económica según R184.
        /// </summary>
        [JsonProperty("ACTIVIDAD_R184")]
        public string? Actividad_R184 { get; set; }

        /// <summary>
        /// Persona relacionada según R184.
        /// </summary>
        [JsonProperty("PERSONA_R184")]
        public string? Persona_R184 { get; set; }

        /// <summary>
        /// Descripción de la actividad económica.
        /// </summary>
        [JsonProperty("ACTIVIDAD")]
        public string? Actividad { get; set; }

        /// <summary>
        /// Código de correo.
        /// </summary>
        [JsonProperty("CODIGO_CORREO")]
        public string? Codigo_Correo { get; set; }

        /// <summary>
        /// Código de casilla.
        /// </summary>
        [JsonProperty("CODIGO_CASILLA")]
        public string? Codigo_Casilla { get; set; }

        /// <summary>
        /// Tipo de correspondencia.
        /// </summary>
        [JsonProperty("CORRESPONDENCIA")]
        public string? Correspondencia { get; set; }

        /// <summary>
        /// Tipo de chequera.
        /// </summary>
        [JsonProperty("TIPO_CHEQUERA")]
        public string? Tipo_Chequera { get; set; }

        /// <summary>
        /// Clase de cuenta.
        /// </summary>
        [JsonProperty("CLASE_CUENTA")]
        public string? Clase_Cuenta { get; set; }

        /// <summary>
        /// Tipo de banca.
        /// </summary>
        [JsonProperty("TIPO_BANCA")]
        public string? Tipo_Banca { get; set; }

        /// <summary>
        /// Documentos pendientes.
        /// </summary>
        [JsonProperty("DOCUMENTOS_PEND")]
        public string? Documentos_Pend { get; set; }

        /// <summary>
        /// Origen del cliente.
        /// </summary>
        [JsonProperty("ORIGEN_CLIENTE")]
        public string? Origen_Cliente { get; set; }

        /// <summary>
        /// Ventas anuales.
        /// </summary>
        [JsonProperty("VENTAS_ANUALES")]
        public string? Ventas_Anuales { get; set; }

        /// <summary>
        /// Nombre en la chequera o libreta.
        /// </summary>
        [JsonProperty("NOMBRE_CHEQ_LIBRETA")]
        public string? Nombre_Cheq_Libreta { get; set; }

        /// <summary>
        /// Indica si tiene tarjeta de débito.
        /// </summary>
        [JsonProperty("TARJETA_DEBITO")]
        public string? Tarjeta_Debito { get; set; }

        /// <summary>
        /// Nombre en la tarjeta.
        /// </summary>
        [JsonProperty("NOMBRE_TARJETA")]
        public string? Nombre_Tarjeta { get; set; }

        /// <summary>
        /// Depósito inicial.
        /// </summary>
        [JsonProperty("DEPOSITO_INICIAL")]
        public string? Deposito_Inicial { get; set; }

        /// <summary>
        /// Depósito de cheque provisional.
        /// </summary>
        [JsonProperty("DEPOSITO_CHEQUE_PROV")]
        public string? Deposito_Cheque_Prov { get; set; }

        /// <summary>
        /// Número de transacción.
        /// </summary>
        [JsonProperty("NUMERO_TRANSACCION")]
        public string? Numero_Transaccion { get; set; }

        /// <summary>
        /// Valor de la transacción.
        /// </summary>
        [JsonProperty("VALOR_TRANSACCION")]
        public string? Valor_Transaccion { get; set; }

        /// <summary>
        /// Código de trato.
        /// </summary>
        [JsonProperty("CODIGO_TRATO")]
        public string? Codigo_Trato { get; set; }

        /// <summary>
        /// Fecha de vencimiento.
        /// </summary>
        [JsonProperty("FECHA_VENCIMIENTO")]
        public string? Fecha_Vencimiento { get; set; }

        /// <summary>
        /// Valor de sobregiro.
        /// </summary>
        [JsonProperty("VALOR_SOBREGIRO")]
        public string? Valor_Sobregiro { get; set; }

        /// <summary>
        /// Valor del patrimonio.
        /// </summary>
        [JsonProperty("VALOR_PATRIMONIO")]
        public string? Valor_Patrimonio { get; set; }

        /// <summary>
        /// Fecha del patrimonio.
        /// </summary>
        [JsonProperty("FECHA_PATRIMONIO")]
        public string? Fecha_Patrimonio { get; set; }

        /// <summary>
        /// Fondo de respaldo CNB.
        /// </summary>
        [JsonProperty("FONDO_RESPALDO_CNB")]
        public string? Fondo_Respaldo_Cnb { get; set; }

        /// <summary>
        /// Tipo de moneda.
        /// </summary>
        [JsonProperty("TIPO_MONEDA")]
        public string? Tipo_Moneda { get; set; }

        /// <summary>
        /// Código de políticas OFAC.
        /// </summary>
        [JsonProperty("CODIGO_POLITICAS_OFAC")]
        public string? Codigo_Politicas_Ofac { get; set; }

        /// <summary>
        /// Descripción de políticas OFAC.
        /// </summary>
        [JsonProperty("DESCRIPCION_POL_OFAC")]
        public string? Descripcion_Pol_Ofac { get; set; }

        /// <summary>
        /// Verificación de dirección.
        /// </summary>
        [JsonProperty("VERIFICA_DIRECCION")]
        public string? Verifica_Direccion { get; set; }

        /// <summary>
        /// Número de planilla.
        /// </summary>
        [JsonProperty("NUM_PLANILLA")]
        public string? Num_Planilla { get; set; }

        /// <summary>
        /// Empresa.
        /// </summary>
        [JsonProperty("EMPRESA")]
        public string? Empresa { get; set; }

        /// <summary>
        /// Fecha de planilla.
        /// </summary>
        [JsonProperty("FECHA_PLANILLA")]
        public string? Fecha_Planilla { get; set; }

        /// <summary>
        /// Lista de representantes.
        /// </summary>
        [JsonProperty("REPRESENTANTES")]
        public List<Representante>? Representantes { get; set; }

        /// <summary>
        /// Usuario que realizó la adición.
        /// </summary>
        [JsonProperty("USUARIO_ADICION")]
        public string? Usuario_Adicion { get; set; }

        /// <summary>
        /// Identificación alterna.
        /// </summary>
        [JsonProperty("IDENTIFICACION_ALTERNO")]
        public string? Identificacion_Alterno { get; set; }

        /// <summary>
        /// Nombre de la cuenta.
        /// </summary>
        [JsonProperty("NOMBRE_CUENTA")]
        public string? Nombre_Cuenta { get; set; }

        /// <summary>
        /// Agencia del cliente.
        /// </summary>
        [JsonProperty("AGENCIA_CLIENTE")]
        public string? Agencia_Cliente { get; set; }

        /// <summary>
        /// Nuevo email.
        /// </summary>
        [JsonProperty("EMAIL_NEW")]
        public string? Email_New { get; set; }

        /// <summary>
        /// Nueva actividad registrada.
        /// </summary>
        [JsonProperty("ACTIVIDAD_REG_NEW")]
        public string? Actividad_Reg_New { get; set; }

        /// <summary>
        /// Asignación de cuenta adicional.
        /// </summary>
        [JsonProperty("ASIGNAR_CTA_ADIC")]
        public string? Asignar_Cta_Adic { get; set; }
    }
}
