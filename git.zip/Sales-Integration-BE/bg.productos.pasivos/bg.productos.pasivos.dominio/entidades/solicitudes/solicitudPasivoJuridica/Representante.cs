﻿using Newtonsoft.Json;

namespace bg.productos.pasivos.dominio.entidades.solicitudes.solicitudPasivoJuridica
{
    public class Representante
    {
        /// <summary>
        /// Nombre del representante.
        /// </summary>
        [JsonProperty("NOMBREREP")]
        public string? NombreRep { get; set; }

        /// <summary>
        /// Relación del representante con el titular.
        /// </summary>
        [JsonProperty("RELACIONREP")]
        public string? RelacionRep { get; set; }

        /// <summary>
        /// Tipo de identificación del representante.
        /// </summary>
        [JsonProperty("TIPOIDREP")]
        public string? TipoIdRep { get; set; }

        /// <summary>
        /// Código de identificación del representante.
        /// </summary>
        [JsonProperty("CODIGOIDREP")]
        public string? CodigoIdRep { get; set; }

        /// <summary>
        /// Tipo de cuenta bancaria del representante.
        /// </summary>
        [JsonProperty("TIPOBANCAREP")]
        public string? TipoBancaRep { get; set; }

        /// <summary>
        /// Sexo del representante.
        /// </summary>
        [JsonProperty("SEXOREP")]
        public string? SexoRep { get; set; }

        /// <summary>
        /// Fecha de nacimiento del representante.
        /// </summary>
        [JsonProperty("FECHANACIMIENTOREP")]
        public string? FechaNacimientoRep { get; set; }

        /// <summary>
        /// Nacionalidad del representante.
        /// </summary>
        [JsonProperty("NACIONALIDADREP")]
        public string? NacionalidadRep { get; set; }
    }
}
